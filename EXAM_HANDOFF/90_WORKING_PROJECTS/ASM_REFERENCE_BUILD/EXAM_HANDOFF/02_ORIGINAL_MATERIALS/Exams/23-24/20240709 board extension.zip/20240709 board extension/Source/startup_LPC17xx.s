;/*****************************************************************************
; * @file:    startup_LPC17xx.s
; * @purpose: CMSIS Cortex-M3 Core Device Startup File 
; *           for the NXP LPC17xx Device Series 
; * @version: V1.01
; * @date:    21. December 2009
; *------- <<< Use Configuration Wizard in Context Menu >>> ------------------
; *
; * Copyright (C) 2009 ARM Limited. All rights reserved.
; * ARM Limited (ARM) is supplying this software for use with Cortex-M3 
; * processor based microcontrollers.  This file can be freely distributed 
; * within development tools that are supporting such ARM based processors. 
; *
; * THIS SOFTWARE IS PROVIDED "AS IS".  NO WARRANTIES, WHETHER EXPRESS, IMPLIED
; * OR STATUTORY, INCLUDING, BUT NOT LIMITED TO, IMPLIED WARRANTIES OF
; * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE APPLY TO THIS SOFTWARE.
; * ARM SHALL NOT, IN ANY CIRCUMSTANCES, BE LIABLE FOR SPECIAL, INCIDENTAL, OR
; * CONSEQUENTIAL DAMAGES, FOR ANY REASON WHATSOEVER.
; *
; *****************************************************************************/


; <h> Stack Configuration
;   <o> Stack Size (in Bytes) <0x0-0xFFFFFFFF:8>
; </h>

Stack_Size      EQU     0x00000400

                AREA    STACK, NOINIT, READWRITE, ALIGN=3
Stack_Mem       SPACE   Stack_Size
__initial_sp


; <h> Heap Configuration
;   <o>  Heap Size (in Bytes) <0x0-0xFFFFFFFF:8>
; </h>

Heap_Size       EQU     0x00000000

                AREA    HEAP, NOINIT, READWRITE, ALIGN=3
__heap_base
Heap_Mem        SPACE   Heap_Size
__heap_limit


                PRESERVE8
                THUMB


; Vector Table Mapped to Address 0 at Reset

                AREA    RESET, DATA, READONLY
                EXPORT  __Vectors

__Vectors       DCD     __initial_sp              ; Top of Stack
                DCD     Reset_Handler             ; Reset Handler
                DCD     NMI_Handler               ; NMI Handler
                DCD     HardFault_Handler         ; Hard Fault Handler
                DCD     MemManage_Handler         ; MPU Fault Handler
                DCD     BusFault_Handler          ; Bus Fault Handler
                DCD     UsageFault_Handler        ; Usage Fault Handler
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     0                         ; Reserved
                DCD     SVC_Handler               ; SVCall Handler
                DCD     DebugMon_Handler          ; Debug Monitor Handler
                DCD     0                         ; Reserved
                DCD     PendSV_Handler            ; PendSV Handler
                DCD     SysTick_Handler           ; SysTick Handler

                ; External Interrupts
                DCD     WDT_IRQHandler            ; 16: Watchdog Timer
                DCD     TIMER0_IRQHandler         ; 17: Timer0
                DCD     TIMER1_IRQHandler         ; 18: Timer1
                DCD     TIMER2_IRQHandler         ; 19: Timer2
                DCD     TIMER3_IRQHandler         ; 20: Timer3
                DCD     UART0_IRQHandler          ; 21: UART0
                DCD     UART1_IRQHandler          ; 22: UART1
                DCD     UART2_IRQHandler          ; 23: UART2
                DCD     UART3_IRQHandler          ; 24: UART3
                DCD     PWM1_IRQHandler           ; 25: PWM1
                DCD     I2C0_IRQHandler           ; 26: I2C0
                DCD     I2C1_IRQHandler           ; 27: I2C1
                DCD     I2C2_IRQHandler           ; 28: I2C2
                DCD     SPI_IRQHandler            ; 29: SPI
                DCD     SSP0_IRQHandler           ; 30: SSP0
                DCD     SSP1_IRQHandler           ; 31: SSP1
                DCD     PLL0_IRQHandler           ; 32: PLL0 Lock (Main PLL)
                DCD     RTC_IRQHandler            ; 33: Real Time Clock
                DCD     EINT0_IRQHandler          ; 34: External Interrupt 0
                DCD     EINT1_IRQHandler          ; 35: External Interrupt 1
                DCD     EINT2_IRQHandler          ; 36: External Interrupt 2
                DCD     EINT3_IRQHandler          ; 37: External Interrupt 3
                DCD     ADC_IRQHandler            ; 38: A/D Converter
                DCD     BOD_IRQHandler            ; 39: Brown-Out Detect
                DCD     USB_IRQHandler            ; 40: USB
                DCD     CAN_IRQHandler            ; 41: CAN
                DCD     DMA_IRQHandler            ; 42: General Purpose DMA
                DCD     I2S_IRQHandler            ; 43: I2S
                DCD     ENET_IRQHandler           ; 44: Ethernet
                DCD     RIT_IRQHandler            ; 45: Repetitive Interrupt Timer
                DCD     MCPWM_IRQHandler          ; 46: Motor Control PWM
                DCD     QEI_IRQHandler            ; 47: Quadrature Encoder Interface
                DCD     PLL1_IRQHandler           ; 48: PLL1 Lock (USB PLL)
				DCD		USBActivity_IRQHandler    ; USB Activity interrupt to wakeup
				DCD		CANActivity_IRQHandler    ; CAN Activity interrupt to wakeup


                IF      :LNOT::DEF:NO_CRP
                AREA    |.ARM.__at_0x02FC|, CODE, READONLY
CRP_Key         DCD     0xFFFFFFFF
                ENDIF


                AREA    |.text|, CODE, READONLY


NUM_ROW EQU 6 
NUM_COL EQU 5
SYScontrolAndStatusReg EQU 0xE000E010
SYSreloadValueReg	EQU 0xE000E014
SYScurrentValueReg	EQU 0xE000E018

				AREA initialMatrix, DATA, READONLY
initial_maze 	DCB 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
				DCB 0xFF, 0, 1, 0, 0xFF
				DCB 0xFF, 0, 0, 0, 0xFF
				DCB 0xFF, 0, 0, 0, 0xFF
				DCB 0xFF, 0, 0, 0, 0xFF
				DCB 0xFF, 0xFF, 0xFF, 0xFF, 0xFF

				AREA currentMatrix, DATA, READWRITE
current_maze	SPACE NUM_ROW * NUM_COL

                AREA    |.text|, CODE, READONLY

; Reset Handler

Reset_Handler   PROC
                EXPORT  Reset_Handler             [WEAK]
                
				; Systick timer initialization
				LDR r0, =SYScontrolAndStatusReg
				MOV r1, #0
				STR r1, [r0]; step1
				
				LDR r0, =SYSreloadValueReg
				LDR r1, =0xFFFFF	
				STR r1, [r0] ; step2
				
				
				LDR r0, =SYScurrentValueReg
				STR r1, [r0] ; step3
				
				
				LDR r0, =SYScontrolAndStatusReg
				MOV r1, #5	; don't generate an interrupt
				STR r1, [r0] ; step4


				MOV r1, #NUM_ROW * NUM_COL
				LDR r0, =initial_maze
				LDR r3, =current_maze
loop_initialization		LDRB r2, [r0], #1
				STRB r2, [r3], #1
				SUBS r1, r1, #1
				BNE loop_initialization
				
				
				LDR r0, =current_maze	; first parameter
				MOV r1, #NUM_ROW
				MOV r2, #NUM_COL
				MOV r3, #7
				BL depthFirstSearch
                
				IMPORT  __main                
                LDR     R0, =__main
                BX      R0
;stop			B stop
                ENDP


depthFirstSearch	PROC
				EXPORT depthFirstSearch
				PUSH {r4-r8, LR}
				; r0 = address of the maze matrix
				; r2 = number of columns NUM_COL
				MOV r6, r2
				; r3 = index of the current cell
				
				MOV r8, #0		; r8 is the number of cells pushed into the stack
				
				ADD r4, r0, r3		; r4 = address of the current cell
				
				; Set r0 = 0 if the neighboring cell at the right has not been visited, 1 otherwise
next			ADD r5, r4, #1		; r5 = address of the neighbor at the right
				LDRB r0, [r5]	
				AND r0, r0, #1
				
				;Set r1 = 0 if the neighboring cell at the bottom has not been visited, 1 otherwise
				ADD r5, r4, r6		; r5 = address of the neighbor at the bottom
				LDRB r1, [r5]	
				AND r1, r1, #1
				
				;set r2= 0 if the neighboring cell at the left has not been visited, 1 otherwise
				SUB r5, r4, #1		; r5 = address of the neighbor at the left
				LDRB r2, [r5]	
				AND r2, r2, #1
				
				; Set r3 = 0 if the neighboring cell at the top has not been visited, 1 otherwise
				SUB r5, r4, r6		; r5 = address of the neighbor at the top
				LDRB r3, [r5]	
				AND r3, r3, #1
				
				;BL chooseNeighbor
				BL chooseRandomNeighbor
				
				CMP r0, #0
				BEQ noUnvisitedNeighbors
				
				PUSH {r4}		; index of the current cell
				ADD r8, r8, #1
				
				CMP r0, #1
				BEQ passage_right
				
				CMP r0, #2
				BEQ passage_bottom
				
				CMP r0, #3
				BEQ passage_left
				
				CMP r0, #4
				BEQ passage_top

passage_right	LDRB r0, [r4]
				ORR r0, r0, #2_10
				STRB r0, [r4]
				
				ADD r4, r4, #1		; r4 = address of the neighbor at the right
				LDRB r0, [r4]
				ORR r0, r0, #2_1001
				STRB r0, [r4]
				B next
				
passage_bottom	LDRB r0, [r4]
				ORR r0, r0, #2_100
				STRB r0, [r4]
				
				ADD r4, r4, r6		; r4 = address of the neighbor at the bottom
				LDRB r0, [r4]
				ORR r0, r0, #2_10001
				STRB r0, [r4]
				B next
				
passage_left	LDRB r0, [r4]
				ORR r0, r0, #2_1000
				STRB r0, [r4]
				
				SUB r4, r4, #1		; r4 = address of the neighbor at the left
				LDRB r0, [r4]
				ORR r0, r0, #2_11
				STRB r0, [r4]
				B next

passage_top		LDRB r0, [r4]
				ORR r0, r0, #2_10000
				STRB r0, [r4]
				
				SUB r4, r4, r6		; r4 = address of the neighbor at the top
				LDRB r0, [r4]
				ORR r0, r0, #2_101
				STRB r0, [r4]
				B next

noUnvisitedNeighbors	CMP r8, #0
				BEQ endProcedure
				POP {r4}		; backtracking
				SUB r8, r8, #1
				B next

endProcedure	POP {r4-r8, PC}
				ENDP


chooseNeighbor	PROC
				PUSH {LR}
				CMP r0, #0
				BEQ return1
				; r0 = 1
				MOV r0, #2
				CMP r1, #0
				BEQ return2
				
				; r1 = 1
				MOV r0, #3
				CMP r2, #0
				BEQ return2
				
				; r2 = 1
				MOV r0, #4
				CMP r3, #0
				BEQ return2
				
				MOV r0, #0
				B return2
				
return1			MOV r0, #1
return2			POP {PC}
				ENDP
					
chooseRandomNeighbor	PROC
				PUSH {r4, r5, LR}
				MOV r5, #0	; number of pushed registers
				CMP r0, #0
				BNE next1
				MOV r4, #1
				PUSH {r4}
				ADD r5, r5, #1
				
next1			CMP r1, #0
				BNE next2
				MOV r4, #2
				PUSH {r4}
				ADD r5, r5, #1
				
next2			CMP r2, #0
				BNE next3
				MOV r4, #3
				PUSH {r4}				
				ADD r5, r5, #1
				
next3			CMP r3, #0
				BNE next4
				MOV r4, #4
				PUSH {r4}
				ADD r5, r5, #1
				
next4			MOV r0, #0
				CMP r5, #0
				BEQ endProc
				
				LDR r0, =SYScurrentValueReg
				LDR r1, [r0]
				
				UDIV r2, r1, r5
				MUL r3, r2, r5
				SUB r4, r1, r3	; r4 is the module
				
				LDR r0, [sp, r4, LSL #2]
				ADD sp, sp, r5, LSL #2
				
endProc 		POP {r4, r5, PC}
				ENDP


; Dummy Exception Handlers (infinite loops which can be modified)                

NMI_Handler     PROC
                EXPORT  NMI_Handler               [WEAK]
                B       .
                ENDP
HardFault_Handler\
                PROC
                EXPORT  HardFault_Handler         [WEAK]
                B       .
                ENDP
MemManage_Handler\
                PROC
                EXPORT  MemManage_Handler         [WEAK]
                B       .
                ENDP
BusFault_Handler\
                PROC
                EXPORT  BusFault_Handler          [WEAK]
                B       .
                ENDP
UsageFault_Handler\
                PROC
                EXPORT  UsageFault_Handler        [WEAK]
                B       .
                ENDP
SVC_Handler     PROC
                EXPORT  SVC_Handler               [WEAK]
                B       .
                ENDP
DebugMon_Handler\
                PROC
                EXPORT  DebugMon_Handler          [WEAK]
                B       .
                ENDP
PendSV_Handler  PROC
                EXPORT  PendSV_Handler            [WEAK]
                B       .
                ENDP
SysTick_Handler PROC
                EXPORT  SysTick_Handler           [WEAK]
                B       .
                ENDP

Default_Handler PROC

                EXPORT  WDT_IRQHandler            [WEAK]
                EXPORT  TIMER0_IRQHandler         [WEAK]
                EXPORT  TIMER1_IRQHandler         [WEAK]
                EXPORT  TIMER2_IRQHandler         [WEAK]
                EXPORT  TIMER3_IRQHandler         [WEAK]
                EXPORT  UART0_IRQHandler          [WEAK]
                EXPORT  UART1_IRQHandler          [WEAK]
                EXPORT  UART2_IRQHandler          [WEAK]
                EXPORT  UART3_IRQHandler          [WEAK]
                EXPORT  PWM1_IRQHandler           [WEAK]
                EXPORT  I2C0_IRQHandler           [WEAK]
                EXPORT  I2C1_IRQHandler           [WEAK]
                EXPORT  I2C2_IRQHandler           [WEAK]
                EXPORT  SPI_IRQHandler            [WEAK]
                EXPORT  SSP0_IRQHandler           [WEAK]
                EXPORT  SSP1_IRQHandler           [WEAK]
                EXPORT  PLL0_IRQHandler           [WEAK]
                EXPORT  RTC_IRQHandler            [WEAK]
                EXPORT  EINT0_IRQHandler          [WEAK]
                EXPORT  EINT1_IRQHandler          [WEAK]
                EXPORT  EINT2_IRQHandler          [WEAK]
                EXPORT  EINT3_IRQHandler          [WEAK]
                EXPORT  ADC_IRQHandler            [WEAK]
                EXPORT  BOD_IRQHandler            [WEAK]
                EXPORT  USB_IRQHandler            [WEAK]
                EXPORT  CAN_IRQHandler            [WEAK]
                EXPORT  DMA_IRQHandler            [WEAK]
                EXPORT  I2S_IRQHandler            [WEAK]
                EXPORT  ENET_IRQHandler           [WEAK]
                EXPORT  RIT_IRQHandler            [WEAK]
                EXPORT  MCPWM_IRQHandler          [WEAK]
                EXPORT  QEI_IRQHandler            [WEAK]
                EXPORT  PLL1_IRQHandler           [WEAK]
				EXPORT  USBActivity_IRQHandler    [WEAK]
				EXPORT  CANActivity_IRQHandler    [WEAK]

WDT_IRQHandler           
TIMER0_IRQHandler         
TIMER1_IRQHandler         
TIMER2_IRQHandler         
TIMER3_IRQHandler         
UART0_IRQHandler          
UART1_IRQHandler          
UART2_IRQHandler          
UART3_IRQHandler          
PWM1_IRQHandler           
I2C0_IRQHandler           
I2C1_IRQHandler           
I2C2_IRQHandler           
SPI_IRQHandler            
SSP0_IRQHandler           
SSP1_IRQHandler           
PLL0_IRQHandler           
RTC_IRQHandler            
EINT0_IRQHandler          
EINT1_IRQHandler          
EINT2_IRQHandler          
EINT3_IRQHandler          
ADC_IRQHandler            
BOD_IRQHandler            
USB_IRQHandler            
CAN_IRQHandler            
DMA_IRQHandler          
I2S_IRQHandler            
ENET_IRQHandler       
RIT_IRQHandler          
MCPWM_IRQHandler             
QEI_IRQHandler            
PLL1_IRQHandler           
USBActivity_IRQHandler
CANActivity_IRQHandler

                B       .

                ENDP


                ALIGN


; User Initial Stack & Heap

                IF      :DEF:__MICROLIB
                
                EXPORT  __initial_sp
                EXPORT  __heap_base
                EXPORT  __heap_limit
                
                ELSE
                
                IMPORT  __use_two_region_memory
                EXPORT  __user_initial_stackheap
__user_initial_stackheap

                LDR     R0, =  Heap_Mem
                LDR     R1, =(Stack_Mem + Stack_Size)
                LDR     R2, = (Heap_Mem +  Heap_Size)
                LDR     R3, = Stack_Mem
                BX      LR

                ALIGN

                ENDIF


                END
