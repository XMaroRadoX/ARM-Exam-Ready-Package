.\objects\template.o: Source\template.s
