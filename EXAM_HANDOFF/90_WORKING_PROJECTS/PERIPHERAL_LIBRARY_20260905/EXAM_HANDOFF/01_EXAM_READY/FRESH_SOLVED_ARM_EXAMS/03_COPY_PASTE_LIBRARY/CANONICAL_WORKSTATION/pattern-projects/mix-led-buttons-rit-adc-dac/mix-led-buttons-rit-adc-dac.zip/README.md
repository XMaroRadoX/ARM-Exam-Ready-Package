# mix-led-buttons-rit-adc-dac

Compose a board monitor using LED, Buttons, RIT, ADC, DAC. INT0 toggles running and KEY1 selects the output mode. ADC sets the value and analog amplitude. LEDs show the low eight bits. DAC holds a static voltage; this combination makes no audio-frequency claim. Inspect app, output_ticks and supervisor_ticks in the debugger for components without a visible output.

## Run and inspect

Reset: running=1, value=0. For available inputs: INT0 pauses; KEY2 resets; RIGHT increments; ADC 4095 sets value=255 and amplitude=1023. Release inputs between commands.

## Resource ownership

- P2.0�P2.7: board labels LD11�LD4; byte display mask
- P2.10 INT0, P2.11 KEY1, P2.12 KEY2; active low
- 10 ms input sampling; RIT_IRQHandler acknowledges the interrupt
- P1.31 / AD0.5 potentiometer; 0�4095; one conversion at a time
- P0.26 / AOUT speaker; 0�1023; timed waveform with Timer1, static voltage otherwise
- Foreground: sole controller state owner; bounded FIFO of 31 usable snapshots; loss counter on overflow

## Files to replace

Open sample.uvprojx. All files below are already installed in this project. To adapt another template copy, replace these exact files; do not add a second handler.
- Source/sample.c
- Source/ASM_funct.s
- Source/button_EXINT/IRQ_button.c
- Source/timer/IRQ_timer.c
- Source/RIT/IRQ_RIT.c
- Source/systick/IRQ_systick.c
- Source/adc/IRQ_adc.c
