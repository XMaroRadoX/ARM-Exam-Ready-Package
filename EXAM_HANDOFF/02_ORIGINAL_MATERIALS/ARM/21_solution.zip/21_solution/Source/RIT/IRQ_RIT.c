/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "GLCD.h"


/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/

extern int current_row, current_column;
extern uint8_t maze[NUM_ROW][NUM_COL];
extern int ticks;

void RIT_IRQHandler (void)
{					
	static int down=0, left=0, right=0, up=0;	
	
	if((LPC_GPIO1->FIOPIN & (1<<26)) == 0){	
		/* Joystick DOWN pressed */
		down++;
		if (down == 1)
		{
				/* if bit 2 is 1, there is a wall at the bottom */
				if ((maze[current_row][current_column] & (1 << 2)) != 0)
				{
					draw_position(current_column, current_row, ZOOM, Black);
					current_row += 1;
					draw_position(current_column, current_row, ZOOM, White);
					disable_timer(0);
					reset_timer(0);
					init_timer(0,2120);
					ticks = 0;
					enable_timer(0);
				}
		}
	}
	else {
			down=0;
	}

	if((LPC_GPIO1->FIOPIN & (1<<27)) == 0){	
		/* Joystick LEFT pressed */
		left++;
		if (left == 1)
		{
				/* if bit 3 is 1, there is a wall at the left */
				if ((maze[current_row][current_column] & (1 << 3)) != 0)
				{
					draw_position(current_column, current_row, ZOOM, Black);
					current_column -= 1;
					draw_position(current_column, current_row, ZOOM, White);
					disable_timer(0);
					reset_timer(0);
					init_timer(0,1890);
					ticks = 0;
					enable_timer(0);
				}
		}
	}
	else {
			left=0;
	}

	if((LPC_GPIO1->FIOPIN & (1<<28)) == 0){	
		/* Joystick RIGHT pressed */
		right++;
		if (right == 1)
		{
				/* if bit 1 is 1, there is a wall at the bottom */
				if ((maze[current_row][current_column] & (1 << 1)) != 0)
				{
					draw_position(current_column, current_row, ZOOM, Black);
					current_column += 1;
					draw_position(current_column, current_row, ZOOM, White);
					disable_timer(0);
					reset_timer(0);
					init_timer(0,1684);
					ticks = 0;
					enable_timer(0);
				}
		}
	}
	else {
			right=0;
	}
	
	if((LPC_GPIO1->FIOPIN & (1<<29)) == 0){	
		/* Joystick UP pressed */
		up++;
		if (up == 1)
		{
				/* if bit 4 is 1, there is a wall at the top */
				if ((maze[current_row][current_column] & (1 << 4)) != 0)
				{
					draw_position(current_column, current_row, ZOOM, Black);
					current_row -= 1;
					draw_position(current_column, current_row, ZOOM, White);
					disable_timer(0);
					reset_timer(0);
					init_timer(0,1592);
					ticks = 0;
					enable_timer(0);
				}
		}
	}
	else {
			up=0;
	}
	
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
  return;
}

/******************************************************************************
**                            End Of File
******************************************************************************/
