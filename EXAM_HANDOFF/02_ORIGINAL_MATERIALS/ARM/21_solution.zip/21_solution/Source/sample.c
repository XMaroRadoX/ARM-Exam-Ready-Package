/****************************************Copyright (c)****************************************************
**                                      
**                                 http://www.powermcu.com
**
**--------------File Info---------------------------------------------------------------------------------
** File name:               main.c
** Descriptions:            The GLCD application function
**
**--------------------------------------------------------------------------------------------------------
** Created by:              AVRman
** Created date:            2010-11-7
** Version:                 v1.0
** Descriptions:            The original version
**
**--------------------------------------------------------------------------------------------------------
** Modified by:             Paolo Bernardi
** Modified date:           03/01/2020
** Version:                 v2.0
** Descriptions:            basic program for LCD and Touch Panel teaching
**
*********************************************************************************************************/

/* Includes ------------------------------------------------------------------*/
#include "LPC17xx.h"
#include "GLCD.h" 
#include "joystick.h"
#include "RIT.h"

extern void depthFirstSearch(uint8_t* maze, int rows, int cols, int starting_cell);
	

uint8_t maze[NUM_ROW][NUM_COL];
int current_row = 1;
int current_column = 2;

#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif


int main(void)
{
  SystemInit();  												/* System Initialization (i.e., PLL)  */
	
	int i, j, initial_position;
	for (i = 0; i < NUM_ROW; i ++)
		for (j = 0; j < NUM_COL; j ++)
		{
			if ((i == 0) || (i == NUM_ROW - 1))
				maze[i][j] = 255;
			else if ((j == 0) || (j == NUM_COL - 1))
				maze[i][j] = 255;
		}
	maze[current_row][current_column] = 1;
	initial_position = current_row * NUM_COL + current_column;
	depthFirstSearch((uint8_t*) maze, NUM_ROW, NUM_COL, initial_position);
	
  LCD_Initialization();
	LCD_Clear(Black);
	LCD_draw_maze(NUM_ROW, NUM_COL, maze, ZOOM);
	draw_position(current_column, current_row, ZOOM, White);

	/* DAC initialization */
	LPC_PINCON->PINSEL1 |= (1<<21);
	LPC_PINCON->PINSEL1 &= ~(1<<20);			/* pin 0.26 is AOUT */
	LPC_GPIO0->FIODIR |= (1<<26);					/* needed only for software debugging */
		
	joystick_init();											/* Joystick Initialization            */
	init_RIT(0x004C4B40);									/* RIT Initialization 50 msec       	*/
	enable_RIT();			
		
	LPC_SC->PCON |= 0x1;									/* power-down	mode										*/
	LPC_SC->PCON &= ~(0x2);						
	SCB->SCR |= 0x2;											/* set SLEEPONEXIT */
	
	__ASM("wfi");

}

/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
