./objects/lib_can.o: Source\CAN\lib_CAN.c \
  C:\Users\paolo\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.1\Device\Include\LPC17xx.h \
  Source\CMSIS_core\core_cm3.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\stdint.h \
  Source\CMSIS_core\cmsis_version.h Source\CMSIS_core\cmsis_compiler.h \
  Source\CMSIS_core\cmsis_armclang.h Source\CMSIS_core\mpu_armv7.h \
  C:\Users\paolo\AppData\Local\Arm\Packs\Keil\LPC1700_DFP\2.7.1\Device\Include\system_LPC17xx.h \
  Source\CAN\CAN.h Source\CAN\..\TouchPanel\TouchPanel.h \
  Source\CAN\..\GLCD\GLCD.h
