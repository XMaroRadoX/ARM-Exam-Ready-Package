./objects/asciilib.o: Source\GLCD\AsciiLib.c Source\GLCD\AsciiLib.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\string.h
