./objects/hzlib.o: Source\GLCD\HzLib.c Source\GLCD\HzLib.h \
  C:\Keil_v5\ARM\ARMCLANG\Bin\..\include\string.h
