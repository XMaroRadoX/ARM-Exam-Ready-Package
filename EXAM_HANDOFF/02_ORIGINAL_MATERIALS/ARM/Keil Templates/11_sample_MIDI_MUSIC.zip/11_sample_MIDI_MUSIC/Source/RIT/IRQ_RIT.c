/*********************************************************************************************************
**--------------File Info---------------------------------------------------------------------------------
** File name:           IRQ_RIT.c
** Last modified Date:  2014-09-25
** Last Version:        V1.00
** Descriptions:        functions to manage T0 and T1 interrupts
** Correlated files:    RIT.h
**--------------------------------------------------------------------------------------------------------
*********************************************************************************************************/
#include "LPC17xx.h"
#include "RIT.h"
#include "led.h"
#include "timer.h"

/******************************************************************************
** Function name:		RIT_IRQHandler
**
** Descriptions:		REPETITIVE INTERRUPT TIMER handler
**
** parameters:			None
** Returned value:		None
**
******************************************************************************/
// beat 1/4 = 1.65/4 seconds
#define RIT_SEMIMINIMA 8
#define RIT_MINIMA 16
#define RIT_INTERA 32

#define UPTICKS 1


//SHORTENING UNDERTALE: TOO MANY REPETITIONS
NOTE song[] = 
{
	// 1
	{d3, time_semicroma},
	{d3, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 2
	{c3, time_semicroma},
	{c3, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 3
	{c3b, time_semicroma},
	{c3b, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 4
	{a2b, time_semicroma},
	{a2b, time_semicroma},
	{d4, time_croma},
	{a3, time_croma},
	{pause, time_semicroma},
	{a3b, time_semicroma},
	{pause, time_semicroma},
	{g3, time_croma},
	{f3, time_semicroma*2},
	{d3, time_semicroma},
	{f3, time_semicroma},
	{g3, time_semicroma},
	// 5
	
};

NOTE song2[] =
{
    /* Jingle Bells � verse */
    {e4, time_croma}, {e4, time_croma}, {e4, time_semicroma*2},
    {e4, time_croma}, {e4, time_croma}, {e4, time_semicroma*2},
    {e4, time_croma}, {g4, time_croma}, {c4, time_croma},
    {d4, time_croma}, {e4, time_semicroma*2},
    {f4, time_croma}, {f4, time_croma}, {f4, time_croma},
    {f4, time_croma}, {e4, time_croma},
    {e4, time_croma}, {e4, time_croma},
    {e4, time_croma}, {d4, time_croma}, {d4, time_croma},
    {e4, time_croma}, {d4, time_semicroma*2},
    {g4, time_semicroma*2},
    {pause, time_croma},

    /* chorus */
    {e4, time_croma}, {e4, time_croma}, {e4, time_semicroma*2},
    {e4, time_croma}, {e4, time_croma}, {e4, time_semicroma*2},
    {e4, time_croma}, {g4, time_croma}, {c4, time_croma},
    {d4, time_croma}, {e4, time_semicroma*2},
    {f4, time_croma}, {f4, time_croma}, {f4, time_croma},
    {f4, time_croma}, {e4, time_croma},
    {e4, time_croma}, {e4, time_croma},
    {g4, time_croma}, {g4, time_croma},
    {f4, time_croma}, {d4, time_croma},
    {c4, time_semicroma*4},
    {pause, time_semicroma*2}
};


void RIT_IRQHandler (void)
{
	static int currentNote = 0;
	static int ticks = 0;
	if(!isNotePlaying())
	{
		++ticks;
		if(ticks == UPTICKS)
		{
			ticks = 0;
			playNote(song[currentNote++]);
		}
	}
	
	if(currentNote == (sizeof(song) / sizeof(song[0])))
	{
		// choose one of the following
		disable_RIT();		// stop the music
		// currentNote = 0;	// restart the music
	}
  LPC_RIT->RICTRL |= 0x1;	/* clear interrupt flag */
}
/******************************************************************************
**                            End Of File
******************************************************************************/
