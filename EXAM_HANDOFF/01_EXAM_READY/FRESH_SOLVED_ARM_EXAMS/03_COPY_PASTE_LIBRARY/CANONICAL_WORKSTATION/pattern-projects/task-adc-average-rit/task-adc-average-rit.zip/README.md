# task-adc-average-rit

Average the samples received so far, then maintain an eight-element sliding window.

## Run and inspect

Eight 4095 samples => mean 4095; next zero => mean 3583; output 223.

## Resource ownership

- P2.0�P2.7: board labels LD11�LD4; byte display mask
- 10 ms input sampling; RIT_IRQHandler acknowledges the interrupt
- P1.31 / AD0.5 potentiometer; 0�4095; one conversion at a time
- Foreground: sole controller state owner; bounded FIFO of 31 usable snapshots; loss counter on overflow

## Files to replace

Open sample.uvprojx. All files below are already installed in this project. To adapt another template copy, replace these exact files; do not add a second handler.
- Source/sample.c
- Source/ASM_funct.s
- Source/button_EXINT/IRQ_button.c
- Source/timer/IRQ_timer.c
- Source/RIT/IRQ_RIT.c
- Source/systick/IRQ_systick.c
- Source/adc/IRQ_adc.c
