# E2026-02-18-A2 - code start here

## E2026-02-18-A2-Q1

Generate the Hofstadter-Conway variant iteratively in a word array with correct seeds, recurrence-derived indexes and requested aggregate/result.

- `PAT-AAPCS-NONLEAF-001`: [nonleaf_function.s](../../../../deliverables/selected_arm_kit/templates/01_aapcs/nonleaf_function.s) - Save LR before the first BL and save an even total number of registers.
- `PAT-ALG-RECURRENCE-001`: [recurrence_into_array.s](../../../../deliverables/selected_arm_kit/templates/02_algorithms/recurrence_into_array.s) - Change the seed block and the one recurrence-rule block; keep the array ABI.
- `PAT-MEM-MATRIX-ROW-MAJOR-001`: [matrix_row_major_byte.s](../../../../deliverables/selected_arm_kit/templates/02_algorithms/matrix_row_major_byte.s) - Compute row * columns + column, then apply the element-size or packed-bit transform.
- `PAT-MEM-WORD-ARRAY-001`: [array_scan_word.s](../../../../deliverables/selected_arm_kit/templates/02_algorithms/array_scan_word.s) - Use LSL #2 scaled addressing and pass element count, not byte count.
- `PAT-AAPCS-STACK-SAFETY-001`: [nonleaf_function.s](../../../../deliverables/selected_arm_kit/templates/01_aapcs/nonleaf_function.s) - Preserve R4-R11, save LR before BL, and push an even register count.
- `PAT-TIMER-FREE-RUNNING-001`: [free_running_timer.c](../../../../deliverables/selected_arm_kit/templates/03_board/free_running_timer.c) - Use the counter as a seed/capture and do not enable the match interrupt unless required.

## E2026-02-18-A2-Q2

Implement the three-timer, DAC and 50 ms scheduling variant, including frequency/duration calculations and explicit running/stopped states.

- `PAT-ALG-FREQUENCY-COUNT-001`: [exam_asm.s](../../../../deliverables/solved_exam_examples/2026-06-25_ARM1_BullsAndCows/Source/exam/exam_asm.s) - Choose frequency counters for a small value range or used markers for general values.
- `PAT-ADC-SAMPLE-001`: [adc_to_leds.c](../../../../deliverables/selected_arm_kit/templates/03_board/adc_to_leds.c) - Normalize the 12-bit sample once, then pass the value to a small policy function.
- `PAT-DAC-STREAM-001`: [dac_table_stream.c](../../../../deliverables/selected_arm_kit/templates/03_board/dac_table_stream.c) - Change sample table and period; keep the ISR index bounded and wrap explicitly.
- `PAT-TIMER-OWNERSHIP-001`: [periodic_timer.c](../../../../deliverables/selected_arm_kit/templates/03_board/periodic_timer.c) - Assign each timer/vector once and keep the callback bounded.
- `PAT-CPU-FLAGS-001`: [apsr_flags.s](../../../../deliverables/selected_arm_kit/templates/04_rare_dangerous/apsr_flags.s) - Use the S-suffixed arithmetic instruction that naturally creates the required flags.
- `PAT-STATE-IRQ-HANDOFF-001`: [periodic_timer.c](../../../../deliverables/selected_arm_kit/templates/03_board/periodic_timer.c) - Make shared events volatile/atomic through the kit API and take them once in foreground.
- `PAT-STATE-EVENT-LOOP-001`: [joystick_state_machine.c](../../../../deliverables/selected_arm_kit/templates/03_board/joystick_state_machine.c) - Callbacks only set bits/data; the foreground loop owns algorithm calls and display changes.
- `PAT-TIMER-PERIODIC-001`: [periodic_timer.c](../../../../deliverables/selected_arm_kit/templates/03_board/periodic_timer.c) - Change the millisecond period and timer ID in the configuration call.

