# PAT-MEM-WORD-ARRAY-001: Word-array traversal

- Recognition tag: `mem:word-array`
- Input/output contract: use the linked exam routine's documented AAPCS prototype.
- Registers: R0-R3 and flags are caller-clobbered; preserve R4-R11.
- Stack: restore SP exactly and keep eight-byte alignment at public call boundaries.
- Signedness/width: select explicit LDRB/LDRSB/LDRH/LDRSH/LDR according to the paper.
- Adaptation: change constants or the localized rule block before changing the ABI.
- Common failures: wrong signed branch, unbalanced early exit, overwritten LR, or unchecked bounds.
- Related exams: `E2023-07-04`, `E2025-02-12-A1`, `E2025-02-12-A2`, `E2025-07-01-A1`, `E2025-07-01-A2`, `E2026-02-03-A1`, `E2026-02-03-A2`, `E2026-02-03-A3`, `E2026-02-18-A1`, `E2026-02-18-A2`, `E2026-06-25-B1`, `E2026-06-25-B2`
- Tests: each related project `Tests/` and `Reports/COVERAGE_MATRIX.csv`.


## Start with actual code

- Canonical: [`array_scan_word.s`](../../../deliverables/selected_arm_kit/templates/02_algorithms/array_scan_word.s)
- Alternative: [`recurrence_into_array.s`](../../../deliverables/selected_arm_kit/templates/02_algorithms/recurrence_into_array.s)
- Code status: `COMPILED_CODE`

## Change these lines first

Use LSL #2 scaled addressing and pass element count, not byte count.

The linked source is the pattern. This page is navigation and adaptation guidance, not a substitute for the code.
