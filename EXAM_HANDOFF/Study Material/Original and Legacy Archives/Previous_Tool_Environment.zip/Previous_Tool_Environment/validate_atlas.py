import csv
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ATLAS = ROOT / "ARM_EXAM_ATLAS"
PROJECTS = ROOT / "deliverables" / "solved_exam_examples"

def load_csv(name):
    with (ATLAS / "indexes" / name).open(encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))

def main():
    exams = load_csv("exams.csv")
    questions = load_csv("questions.csv")
    patterns = load_csv("patterns.csv")
    links = load_csv("exam_pattern_links.csv")
    atlas = json.loads((ATLAS / "indexes" / "atlas.json").read_text(encoding="utf-8"))
    projects = [p for p in PROJECTS.iterdir() if p.is_dir()]
    assert len(exams) == 23, len(exams)
    assert len(questions) == 48, len(questions)
    assert len(patterns) == 28, len(patterns)
    assert len(projects) == 23, len(projects)
    assert atlas["schema_version"] == "1.0"
    assert len({e["exam_id"] for e in exams}) == len(exams)
    assert len({q["question_id"] for q in questions}) == len(questions)
    assert all(re.fullmatch(r"E\d{4}-\d{2}-\d{2}(?:-[A-Z]\d)?", e["exam_id"]) for e in exams)
    assert all(re.fullmatch(r"PAT-[A-Z0-9-]+-\d{3}", p["pattern_id"]) for p in patterns)
    known_patterns = {p["pattern_id"] for p in patterns}
    known_questions = {q["question_id"] for q in questions}
    assert all(x["pattern_id"] in known_patterns and x["question_id"] in known_questions for x in links)
    for e in exams:
        card = ATLAS / "exams" / e["year"] / e["exam_id"][1:] / "EXAM_CARD.md"
        assert card.is_file(), card
    for p in patterns:
        page = ATLAS / "patterns" / p["category"] / f"{p['pattern_id']}.md"
        assert page.is_file(), page
    required = ["EXAM_MAPPING.md", "ADAPTATION_MAP.md", "CHANGE_BUDGET.md",
                "Simulation/simulated_board.c", "Simulation/simulator_main.c",
                "Tests/expected_results.json", "Reports/COVERAGE_MATRIX.csv"]
    for project in projects:
        for item in required:
            assert (project / item).is_file(), project / item
    print(json.dumps({"exams":len(exams),"questions":len(questions),"patterns":len(patterns),
                      "links":len(links),"projects":len(projects),"status":"PASS"}, indent=2))

if __name__ == "__main__": main()
