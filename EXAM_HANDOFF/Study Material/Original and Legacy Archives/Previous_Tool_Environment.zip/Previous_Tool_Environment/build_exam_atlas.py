from __future__ import annotations

import csv
import hashlib
import json
import re
import shutil
import sys
from collections import Counter, defaultdict
from pathlib import Path

LOCAL_PACKAGES = Path(__file__).resolve().parent / "python_packages"
if LOCAL_PACKAGES.exists():
    sys.path.insert(0, str(LOCAL_PACKAGES))

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

ROOT = Path(__file__).resolve().parents[1]
DEL = ROOT / "deliverables"
MATRIX = DEL / "exam_analysis" / "ARM_EXAM_PRIORITY_MATRIX.csv"
PROJECTS = DEL / "solved_exam_examples"
ATLAS = ROOT / "ARM_EXAM_ATLAS"
SPEC = Path(r"C:\Users\marwa\.codex\attachments\6330541d-3ba0-47f0-8e19-f0742da8de33\pasted-text.txt")

STATUS_SIM = "COMPILE_ONLY"
STATUS_HW = "COMPILE_ONLY"
STATUS_PHYS = "PHYSICAL_BOARD_NOT_TESTED"

TAG_RULES = [
    ("alg:sorting", r"sort|ordered"), ("alg:recurrence", r"recurrence|sequence|kaprekar|recaman|look.?and.?say|hofstadter|sociable"),
    ("alg:graph-search", r"maze|path|dfs|kruskal|graph"), ("alg:frequency-count", r"frequency|bulls|mastermind|matches"),
    ("alg:fixed-point", r"fixed.point|q15|sine|cosine|affine"), ("flow:nested-loop", r"nested|matrix|search|sort|maze"),
    ("flow:early-break", r"break|used marker|destination"), ("mem:byte-array", r"byte array|ldrb|strb|ldrsb"),
    ("mem:word-array", r"word array|four arrays|ldr/str|sequence array"), ("mem:matrix-row-major", r"matrix|two-dimensional|2d"),
    ("abi:four-register-args", r"four pointers|r0-r3"), ("abi:stacked-args", r"stacked argument|fifth argument"),
    ("abi:nonleaf", r"nested call|calls another|bl|svc"), ("cpu:flags", r"flag|apsr|overflow|carry"),
    ("cpu:svc", r"svc|supervisor"), ("cpu:exception-frame", r"exception frame|stacked pc|msp/psp"),
    ("board:timer", r"timer|systick"), ("board:gpio", r"led|button|key|int0"),
    ("board:joystick", r"joystick"), ("board:adc", r"adc|potentiometer"), ("board:dac", r"dac|waveform|sintable"),
    ("state:event-loop", r"state machine|event|interrupt-to-main|foreground"), ("state:debounce", r"debounce|bouncing"),
    ("timing:periodic", r"periodic|every|scheduler tick|two-second"), ("timing:free-running", r"free-running|seed"),
    ("risk:stack-alignment", r"stack alignment|preserve lr|callee-saved|r4-r11|sp balanced"),
    ("risk:irq-shared-state", r"volatile|shared|interrupt-to-main|isr"), ("risk:vector-ownership", r"vector ownership|irq ownership|per-vector|multiple timers|three timers"),
]

TAG_DESC = {
    "alg:sorting": "Ordering or insertion/swap logic", "alg:recurrence": "Sequence generated from earlier terms",
    "alg:graph-search": "Graph, maze, reachability, or spanning-tree logic", "alg:frequency-count": "Counts values before comparing multisets",
    "alg:fixed-point": "Scaled-integer arithmetic", "flow:nested-loop": "Loop nested inside another loop",
    "flow:early-break": "Controlled exit from an inner search", "mem:byte-array": "Byte elements and byte loads/stores",
    "mem:word-array": "32-bit elements and scaled addressing", "mem:matrix-row-major": "row * columns + column addressing",
    "abi:four-register-args": "R0-R3 are all consumed by arguments", "abi:stacked-args": "Arguments continue on the caller stack",
    "abi:nonleaf": "Function calls another function and must preserve LR", "cpu:flags": "N/Z/C/V are observed or produced",
    "cpu:svc": "Supervisor call decoding", "cpu:exception-frame": "Hardware exception stack frame",
    "board:timer": "LPC1768 timer or SysTick", "board:gpio": "LED, key, button, or INT0 GPIO",
    "board:joystick": "Joystick input", "board:adc": "Analogue-to-digital conversion", "board:dac": "Digital-to-analogue output",
    "state:event-loop": "ISR-to-foreground event state", "state:debounce": "Confirmed press/release filtering",
    "timing:periodic": "Repeated timed event", "timing:free-running": "Counter runs continuously",
    "risk:stack-alignment": "AAPCS preservation/alignment hazard", "risk:irq-shared-state": "State shared with an interrupt",
    "risk:vector-ownership": "One unambiguous owner per interrupt vector",
}

PATTERNS = {
    "alg:sorting": ("PAT-ALG-SORTING-001", "algorithms", "Signed and unsigned array sorting"),
    "alg:recurrence": ("PAT-ALG-RECURRENCE-001", "algorithms", "Bounded recurrence into an array"),
    "alg:graph-search": ("PAT-ALG-GRAPH-SEARCH-001", "algorithms", "Matrix and graph traversal"),
    "alg:frequency-count": ("PAT-ALG-FREQUENCY-COUNT-001", "algorithms", "Frequency-count comparison"),
    "alg:fixed-point": ("PAT-ALG-FIXED-POINT-001", "algorithms", "Fixed-point multiply and recurrence"),
    "flow:nested-loop": ("PAT-FLOW-NESTED-LOOP-001", "control-flow", "Nested loops with preserved outer state"),
    "flow:early-break": ("PAT-FLOW-EARLY-BREAK-001", "control-flow", "Balanced early exit from inner search"),
    "mem:byte-array": ("PAT-MEM-BYTE-ARRAY-001", "memory", "Signed and unsigned byte arrays"),
    "mem:word-array": ("PAT-MEM-WORD-ARRAY-001", "memory", "Word-array traversal"),
    "mem:matrix-row-major": ("PAT-MEM-MATRIX-ROW-MAJOR-001", "memory", "Row-major matrix addressing"),
    "abi:four-register-args": ("PAT-AAPCS-FOUR-ARGS-001", "aapcs", "Four-register argument contract"),
    "abi:stacked-args": ("PAT-AAPCS-STACKED-ARGS-001", "aapcs", "Fifth and later arguments"),
    "abi:nonleaf": ("PAT-AAPCS-NONLEAF-001", "aapcs", "Non-leaf prologue and epilogue"),
    "cpu:flags": ("PAT-CPU-FLAGS-001", "exceptions", "APSR flag contract"),
    "cpu:svc": ("PAT-CPU-SVC-001", "exceptions", "SVC immediate decoding"),
    "cpu:exception-frame": ("PAT-CPU-EXCEPTION-FRAME-001", "exceptions", "MSP/PSP exception-frame selection"),
    "board:timer": ("PAT-TIMER-OWNERSHIP-001", "timers", "Timer setup and ownership"),
    "board:gpio": ("PAT-GPIO-EVENT-001", "gpio-input", "GPIO event capture"),
    "board:joystick": ("PAT-GPIO-JOYSTICK-001", "gpio-input", "Joystick event state machine"),
    "board:adc": ("PAT-ADC-SAMPLE-001", "adc-dac", "ADC sample conversion"),
    "board:dac": ("PAT-DAC-STREAM-001", "adc-dac", "DAC table streaming"),
    "state:event-loop": ("PAT-STATE-EVENT-LOOP-001", "state-machines", "ISR-to-foreground event loop"),
    "state:debounce": ("PAT-STATE-DEBOUNCE-001", "state-machines", "Deterministic debounce"),
    "timing:periodic": ("PAT-TIMER-PERIODIC-001", "timers", "Periodic match scheduling"),
    "timing:free-running": ("PAT-TIMER-FREE-RUNNING-001", "timers", "Free-running timer seed"),
    "risk:stack-alignment": ("PAT-AAPCS-STACK-SAFETY-001", "aapcs", "Register preservation and stack safety"),
    "risk:irq-shared-state": ("PAT-STATE-IRQ-HANDOFF-001", "state-machines", "Atomic ISR event handoff"),
    "risk:vector-ownership": ("PAT-TIMER-VECTOR-OWNERSHIP-001", "timers", "Exclusive interrupt-vector ownership"),
}

def write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text.rstrip() + "\n", encoding="utf-8")

def rel(path: Path, start: Path) -> str:
    return Path(shutil.os.path.relpath(path, start)).as_posix()

def tags_for(row: dict[str, str]) -> list[str]:
    blob = " ".join(row.values()).lower()
    found = [tag for tag, rx in TAG_RULES if re.search(rx, blob)]
    if row["delivery_mode"].startswith("ASM") and "risk:stack-alignment" not in found:
        found.append("risk:stack-alignment")
    return sorted(set(found))

def project_for(row: dict[str, str], projects: list[Path]) -> Path | None:
    date = row["exam_date"]
    variant = row["variant"].replace("ARM", "ARM")
    candidates = [p for p in projects if p.name.startswith(date)]
    if len(candidates) == 1:
        return candidates[0]
    digits = re.findall(r"\d+", variant)
    if digits:
        exact = [p for p in candidates if f"ARM{digits[-1]}_" in p.name]
        if exact: return exact[0]
    return candidates[0] if candidates else None

def csv_write(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)

def build_project_docs(project: Path, exam_id: str, rows: list[dict], tags: list[str], pattern_ids: list[str]) -> None:
    qids = [r["requirement_id"] for r in rows]
    mapping = "# Exam mapping\n\n" + f"- Exam ID: `{exam_id}`\n- Questions: {', '.join(f'`{q}`' for q in qids)}\n- Tags: {', '.join(f'`{t}`' for t in tags)}\n- Patterns: {', '.join(f'`{p}`' for p in pattern_ids)}\n\n"
    mapping += "| Question | Requirement | Source PDF | Verification |\n|---|---|---|---|\n"
    for r in rows:
        mapping += f"| `{r['requirement_id']}` | {r['exam_requirement']} | `{r['source_file']}` | `{STATUS_SIM}` / `{STATUS_HW}` / `{STATUS_PHYS}` |\n"
    write(project / "EXAM_MAPPING.md", mapping)
    write(project / "ADAPTATION_MAP.md", """# Adaptation map

Change the smallest applicable item first:

| Correction type | Primary change point | Expected change |
|---|---|---|
| Array length, seed, period, pin, or threshold | `platform/exam_config.h` or the constants block in `exam/exam_user.h` | One definition |
| Input/output encoding | Small policy/helper in `exam/exam_user.c` | One localized function |
| Algorithm recurrence or match rule | Named rule block in `exam/exam_asm.s` | One localized assembly block |
| Peripheral ownership | Configuration macros and one initialization call | Configuration plus owner hook |
| Test data | `Tests/expected_results.json` and test vectors | Data only |

Do not edit startup, CMSIS, or the common platform layer for an ordinary paper variation. Keep C prototypes and the R0-R3 assembly contract stable.
""")
    write(project / "CHANGE_BUDGET.md", """# Change budget

The code is organized so the usual correction is localized. The expected budget is a measured target, not permission to skip rebuilding and rerunning tests.

| Variation | Target source lines changed |
|---|---:|
| Constant, array size, timer period, or seed | 1-3 |
| Pin or peripheral instance | 1-4 |
| Result encoding | 3-8 |
| Recurrence or stopping rule | 4-12 |
| Replace the main algorithm family | use another canonical pattern; no honest small-line promise |
""")
    sim = project / "Simulation"
    write(sim / "simulated_board.h", """#ifndef SIMULATED_BOARD_H
#define SIMULATED_BOARD_H
#include <stdint.h>
#define SIM_TIMER_COUNT 4u
typedef struct { uint32_t counter, match, prescale; uint8_t running, reset_on_match, irq_enabled, irq_pending; } sim_timer_t;
typedef struct { sim_timer_t timer[SIM_TIMER_COUNT]; uint32_t ticks, gpio_in, gpio_out, systick_events; uint16_t adc; uint16_t dac_log[256]; uint16_t dac_count; } sim_board_t;
void sim_board_reset(sim_board_t *b);
int sim_timer_config(sim_board_t *b, unsigned id, uint32_t match, uint8_t reset_on_match, uint8_t irq_enabled);
void sim_step(sim_board_t *b, uint32_t ticks);
void sim_gpio_input(sim_board_t *b, uint32_t mask, uint8_t pressed);
void sim_led_write(sim_board_t *b, uint32_t value);
void sim_adc_set(sim_board_t *b, uint16_t value);
int sim_dac_write(sim_board_t *b, uint16_t value);
#endif
""")
    write(sim / "simulated_board.c", """#include "simulated_board.h"
#include <string.h>
void sim_board_reset(sim_board_t *b) { memset(b, 0, sizeof(*b)); }
int sim_timer_config(sim_board_t *b, unsigned id, uint32_t match, uint8_t reset, uint8_t irq) {
  if (id >= SIM_TIMER_COUNT || match == 0u) return -1;
  b->timer[id].match=match; b->timer[id].reset_on_match=reset; b->timer[id].irq_enabled=irq; b->timer[id].running=1u; return 0;
}
void sim_step(sim_board_t *b, uint32_t ticks) {
  unsigned i; b->ticks += ticks;
  for (i=0; i<SIM_TIMER_COUNT; ++i) { sim_timer_t *t=&b->timer[i]; if (!t->running) continue; t->counter += ticks;
    if (t->counter >= t->match) { if (t->irq_enabled) t->irq_pending=1u; if (t->reset_on_match) t->counter %= t->match; }
  }
}
void sim_gpio_input(sim_board_t *b, uint32_t mask, uint8_t pressed) { if (pressed) b->gpio_in |= mask; else b->gpio_in &= ~mask; }
void sim_led_write(sim_board_t *b, uint32_t value) { b->gpio_out=value; }
void sim_adc_set(sim_board_t *b, uint16_t value) { b->adc=(uint16_t)(value & 0x0FFFu); }
int sim_dac_write(sim_board_t *b, uint16_t value) { if (b->dac_count >= 256u || value > 1023u) return -1; b->dac_log[b->dac_count++]=value; return 0; }
""")
    write(sim / "simulator_main.c", """#include "simulated_board.h"
#include <assert.h>
int main(void) { sim_board_t b; sim_board_reset(&b);
  assert(sim_timer_config(&b,0u,10u,1u,1u)==0); sim_step(&b,25u); assert(b.timer[0].counter==5u && b.timer[0].irq_pending);
  sim_gpio_input(&b,4u,1u); assert((b.gpio_in&4u)!=0u); sim_gpio_input(&b,4u,0u); assert((b.gpio_in&4u)==0u);
  sim_adc_set(&b,4095u); assert(b.adc==4095u); assert(sim_dac_write(&b,1023u)==0 && b.dac_log[0]==1023u);
  sim_led_write(&b,0xA5u); assert(b.gpio_out==0xA5u); return 0; }
""")
    write(sim / "keil_debug.ini", """// Keil simulator command template. Load the CortexM3_Simulator target, run to simulator_test_complete,
// inspect simulator_failures, and record the result. A pass must come from executed ARM code, not compilation.
g, simulator_test_complete
""")
    tests = project / "Tests"
    expected = {"exam_id": exam_id, "question_ids": qids, "tags": tags, "pattern_ids": pattern_ids,
                "required_statuses": ["SIMULATOR_EXECUTED_PASS", "HARDWARE_BUILD_PASS", "PHYSICAL_BOARD_NOT_TESTED"],
                "current_status": {"assembly": STATUS_SIM, "hardware": STATUS_HW, "physical": STATUS_PHYS}}
    write(tests / "expected_results.json", json.dumps(expected, indent=2))
    write(tests / "peripheral_scenarios.c", """/* Deterministic peripheral contract tests are in Simulation/simulator_main.c.
 * Keep scenarios data-driven: press/release, timer match/reset, ADC limits, DAC bounds, and event ordering. */
""")
    report = project / "Reports"
    write(report / "TEST_REPORT.md", f"""# Test report

- Exam: `{exam_id}`
- Assembly execution: `{STATUS_SIM}`
- Hardware build: `{STATUS_HW}`
- Physical board: `{STATUS_PHYS}`
- Peripheral model: source and contract tests supplied; status is not promoted until executed.

This report intentionally separates compilation, Cortex-M3 execution, deterministic peripheral modeling, and physical hardware.
""")
    cov = [{"requirement_id": q, "test_id": f"TST-{q}-001", "assembly": STATUS_SIM, "model": STATUS_SIM, "hardware": STATUS_HW, "physical": STATUS_PHYS} for q in qids]
    csv_write(report / "COVERAGE_MATRIX.csv", cov, list(cov[0]) if cov else ["requirement_id"])

def pdf_page(canvas, doc):
    canvas.saveState(); canvas.setFont("Helvetica", 8); canvas.setFillColor(colors.HexColor("#52606d"))
    canvas.drawString(18*mm, 10*mm, "ARM Exam Atlas"); canvas.drawRightString(192*mm, 10*mm, str(doc.page)); canvas.restoreState()

def make_pdf(path: Path, title: str, sections: list[tuple[str, list[str]]]) -> None:
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="AtlasTitle", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=24, leading=29, textColor=colors.HexColor("#173f5f"), alignment=TA_CENTER, spaceAfter=14))
    styles.add(ParagraphStyle(name="AtlasH1", parent=styles["Heading1"], fontName="Helvetica-Bold", textColor=colors.HexColor("#173f5f"), spaceBefore=10, spaceAfter=6))
    styles.add(ParagraphStyle(name="AtlasBody", parent=styles["BodyText"], fontSize=9, leading=12, spaceAfter=5))
    doc = SimpleDocTemplate(str(path), pagesize=A4, rightMargin=18*mm, leftMargin=18*mm, topMargin=17*mm, bottomMargin=16*mm, title=title)
    story = [Spacer(1, 25*mm), Paragraph(title, styles["AtlasTitle"]), Paragraph("Searchable exam, solution-pattern, adaptation, and verification reference", styles["AtlasBody"]), PageBreak()]
    for heading, paras in sections:
        story.append(Paragraph(heading, styles["AtlasH1"]))
        for p in paras: story.append(Paragraph(p.replace("&", "&amp;"), styles["AtlasBody"]))
    doc.build(story, onFirstPage=pdf_page, onLaterPages=pdf_page)

def main() -> None:
    with MATRIX.open(encoding="utf-8-sig") as f: rows = list(csv.DictReader(f))
    projects = sorted(p for p in PROJECTS.iterdir() if p.is_dir())
    for r in rows: r["tags"] = tags_for(r); r["pattern_ids"] = [PATTERNS[t][0] for t in r["tags"] if t in PATTERNS]
    by_exam = defaultdict(list)
    for r in rows: by_exam[r["exam_id"]].append(r)
    exam_rows=[]; question_rows=[]; link_rows=[]; pattern_exams=defaultdict(set)
    for exam_id, erows in sorted(by_exam.items()):
        first=erows[0]; tags=sorted({t for r in erows for t in r["tags"]}); pids=sorted({p for r in erows for p in r["pattern_ids"]})
        project=project_for(first, projects); year=first["exam_date"][:4]; folder=ATLAS/"exams"/year/exam_id.removeprefix("E")
        exam_rows.append({"exam_id":exam_id,"date":first["exam_date"],"year":year,"variant":first["variant"],"source_pdf":first["source_file"],"source_sha256":first["source_sha256"],"project":str(project or ""),"tags":";".join(tags),"pattern_ids":";".join(pids)})
        related=[]
        for other, orows in by_exam.items():
            if other==exam_id: continue
            overlap=len(set(tags)&{t for x in orows for t in x["tags"]})
            if overlap: related.append((overlap,other))
        related=[x[1] for x in sorted(related,reverse=True)[:5]]
        card=f"# {exam_id}\n\n- Date: `{first['exam_date']}`\n- Variant: `{first['variant']}`\n- Source PDF: `{first['source_file']}`\n- SHA-256: `{first['source_sha256']}`\n- Project: `{project}`\n- Tags: {', '.join(f'`{t}`' for t in tags)}\n- Patterns: {', '.join(f'`{p}`' for p in pids)}\n- Related exams: {', '.join(f'`{x}`' for x in related)}\n\n## Questions\n\n"
        for r in erows: card += f"### {r['question']} - {r['delivery_mode']}\n\n{r['exam_requirement']}\n\n**Traps:** {r['abi_stack_irq_risks']}\n\n"
        card += f"## Verification\n\n- Assembly: `{STATUS_SIM}`\n- Peripheral model: `{STATUS_SIM}`\n- Hardware build: `{STATUS_HW}`\n- Physical board: `{STATUS_PHYS}`\n\n## What usually changes\n\nSizes, constants, recurrence rules, timer periods, pins, and result encoding. Start with the project `ADAPTATION_MAP.md`.\n"
        write(folder/"EXAM_CARD.md",card)
        for r in erows:
            qname="Q1_ASSEMBLY.md" if r["question"]=="Q1" else "Q2_BOARD.md"
            write(folder/qname, f"# {r['requirement_id']}\n\n- Delivery: `{r['delivery_mode']}`\n- Tags: {', '.join(f'`{t}`' for t in r['tags'])}\n- Patterns: {', '.join(f'`{p}`' for p in r['pattern_ids'])}\n- Source: `{r['source_file']}`\n\n## Requirement\n\n{r['exam_requirement']}\n\n## Concepts\n\n{r['algorithm_or_code_patterns']}\n\n## Constraints and risks\n\n{r['timing_io_constraints']}; {r['abi_stack_irq_risks']}\n")
            qr={"question_id":r["requirement_id"],"exam_id":exam_id,"question":r["question"],"delivery_mode":r["delivery_mode"],"requirement":r["exam_requirement"],"source_pdf":r["source_file"],"source_sha256":r["source_sha256"],"tags":";".join(r["tags"]),"pattern_ids":";".join(r["pattern_ids"]),"simulator_status":STATUS_SIM,"hardware_status":STATUS_HW,"physical_status":STATUS_PHYS}; question_rows.append(qr)
            for pid in r["pattern_ids"]: link_rows.append({"exam_id":exam_id,"question_id":r["requirement_id"],"pattern_id":pid}); pattern_exams[pid].add(exam_id)
        if project: build_project_docs(project,exam_id,erows,tags,pids)
    # Index pages
    lines=["# Exam index","","| Exam | Date | Variant | Tags |","|---|---|---|---|"]
    for e in exam_rows: lines.append(f"| [{e['exam_id']}]({e['year']}/{e['exam_id'][1:]}/EXAM_CARD.md) | {e['date']} | {e['variant']} | {e['tags'].replace(';', ', ')} |")
    write(ATLAS/"exams"/"INDEX.md","\n".join(lines))
    for year in sorted({e["year"] for e in exam_rows}):
        ys=[e for e in exam_rows if e["year"]==year]; write(ATLAS/"exams"/year/"INDEX.md", "# "+year+" exams\n\n"+"\n".join(f"- [{e['exam_id']}]({e['exam_id'][1:]}/EXAM_CARD.md)" for e in ys))
    pattern_rows=[]
    for tag,(pid,cat,title) in PATTERNS.items():
        exams=sorted(pattern_exams[pid]); pattern_rows.append({"pattern_id":pid,"category":cat,"title":title,"primary_tag":tag,"exam_ids":";".join(exams)})
        write(ATLAS/"patterns"/cat/f"{pid}.md",f"# {pid}: {title}\n\n- Recognition tag: `{tag}`\n- Input/output contract: use the linked exam routine's documented AAPCS prototype.\n- Registers: R0-R3 and flags are caller-clobbered; preserve R4-R11.\n- Stack: restore SP exactly and keep eight-byte alignment at public call boundaries.\n- Signedness/width: select explicit LDRB/LDRSB/LDRH/LDRSH/LDR according to the paper.\n- Adaptation: change constants or the localized rule block before changing the ABI.\n- Common failures: wrong signed branch, unbalanced early exit, overwritten LR, or unchecked bounds.\n- Related exams: {', '.join(f'`{e}`' for e in exams) or 'none'}\n- Tests: each related project `Tests/` and `Reports/COVERAGE_MATRIX.csv`.\n")
    pindex=["# Solution-pattern index","","| Pattern | Category | Tag | Exams |","|---|---|---|---|"]
    for p in pattern_rows: pindex.append(f"| [{p['pattern_id']}]({p['category']}/{p['pattern_id']}.md) | {p['category']} | `{p['primary_tag']}` | {p['exam_ids'].replace(';', ', ')} |")
    write(ATLAS/"patterns"/"INDEX.md","\n".join(pindex))
    write(ATLAS/"TAG_DICTIONARY.md","# Controlled tag dictionary\n\n"+"\n".join(f"- `{t}` - {TAG_DESC[t]}" for t in sorted(TAG_DESC)))
    counts=Counter(t for r in rows for t in r["tags"])
    write(ATLAS/"QUICK_PATTERN_LOOKUP.md","# Quick pattern lookup\n\nSearch these exact tags in the atlas.\n\n"+"\n".join(f"- `{t}` - {n} question(s) - `{PATTERNS[t][0]}`" for t,n in counts.most_common()))
    write(ATLAS/"INDEX.md",f"""# ARM Exam Atlas

Start with [Quick Pattern Lookup](QUICK_PATTERN_LOOKUP.md), browse the [exam chronology](exams/INDEX.md), or open the [solution-pattern index](patterns/INDEX.md).

- Indexed questions: {len(rows)}
- Indexed exams/variants: {len(by_exam)}
- Solved projects: {len(projects)}
- Controlled tags: {len(TAG_DESC)}
- Stable patterns: {len(PATTERNS)}

Verification is explicit: `{STATUS_SIM}`, `{STATUS_HW}`, and `{STATUS_PHYS}` are not interchangeable. Run `tools/run_regression.py` to update executable evidence.
""")
    csv_write(ATLAS/"indexes"/"exams.csv",exam_rows,list(exam_rows[0])); csv_write(ATLAS/"indexes"/"questions.csv",question_rows,list(question_rows[0])); csv_write(ATLAS/"indexes"/"patterns.csv",pattern_rows,list(pattern_rows[0])); csv_write(ATLAS/"indexes"/"exam_pattern_links.csv",link_rows,list(link_rows[0]))
    write(ATLAS/"indexes"/"atlas.json",json.dumps({"schema_version":"1.0","statuses":["SIMULATOR_EXECUTED_PASS","HARDWARE_BUILD_PASS","COMPILE_ONLY","PHYSICAL_BOARD_NOT_TESTED"],"exams":exam_rows,"questions":question_rows,"patterns":pattern_rows,"links":link_rows},indent=2))
    spec_hash=hashlib.sha256(SPEC.read_bytes()).hexdigest() if SPEC.exists() else "missing"
    docs={
      "SIMULATOR_GUIDE.md":"# Simulator guide\n\nEach project contains a deterministic board model under `Simulation/`. The model covers timers, GPIO, ADC, DAC, and ordered events. `COMPILE_ONLY` must never be rewritten as `SIMULATOR_EXECUTED_PASS` unless the linked ARM image executed and its assertions passed. Physical electrical behavior remains `PHYSICAL_BOARD_NOT_TESTED`.\n",
      "EXAM_INDEXING_GUIDE.md":"# Exam indexing guide\n\nIDs, tags, patterns, projects, and tests are linked bidirectionally through `ARM_EXAM_ATLAS/indexes`. Add a new paper by adding question rows with stable IDs, then rerun the atlas builder and link each requirement to a test.\n",
      "SOLUTION_PATTERN_GUIDE.md":"# Solution-pattern guide\n\nRecognize a problem using controlled tags, open its pattern page, then select a linked project. Preserve the AAPCS contract and edit configuration or the named policy block first.\n",
      "REQUIREMENTS_COMPLIANCE.md":f"# Requirements compliance\n\nAuthoritative specification: `{SPEC}`\n\nSHA-256: `{spec_hash}`\n\nThe specification's kit analysis remains in `deliverables/kit_analysis`; its template, index, testing, documentation, source-reference, and completion-report requirements are addressed by the atlas, per-project mappings, controlled tags, simulation sources, coverage matrices, master PDF, and final report. Execution statuses remain evidence-based.\n",
    }
    for name,text in docs.items(): write(DEL/"selected_arm_kit"/name,text)
    write(ROOT/"README.md", "# ARM Exam Ready Package\n\nOpen [ARM_EXAM_ATLAS/INDEX.md](ARM_EXAM_ATLAS/INDEX.md). Originals and kit backups are preserved; deliverables, projects, pattern indexes, tests, and PDFs are linked from the atlas.\n")
    sections=[("How to use the atlas",["Start with Quick Pattern Lookup. Search exact normalized tags, then move from pattern to related exams and the complete project."]),
              ("Coverage",[f"{len(rows)} question requirements, {len(by_exam)} exam variants, {len(projects)} solved projects, {len(PATTERNS)} stable solution patterns."]),
              ("Verification meaning",["COMPILE_ONLY means no execution claim. SIMULATOR_EXECUTED_PASS requires actual linked ARM execution. HARDWARE_BUILD_PASS is a separate LPC1768 build result. PHYSICAL_BOARD_NOT_TESTED is expected while no board is available."]),
              ("Pattern frequency",[f"{tag}: {count} question(s) - {PATTERNS[tag][0]}" for tag,count in counts.most_common()]),
              ("Exam chronology",[f"{e['exam_id']} ({e['variant']}): {e['tags'].replace(';', ', ')}" for e in exam_rows]),
              ("Solution patterns",[f"{p['pattern_id']} - {p['title']}. Exams: {p['exam_ids'].replace(';', ', ') or 'none'}" for p in pattern_rows]),
              ("Adaptation strategy",["Keep prototypes and R0-R3 contracts stable. Change constants, configuration, or one named policy block. Rebuild both targets and rerun all related tests after every correction."]),
              ("Requirements source",[f"The original 1,073-line text specification is authoritative. SHA-256: {spec_hash}. Detailed compliance is maintained in REQUIREMENTS_COMPLIANCE.md."])]
    qsections=[("AAPCS",["R0-R3 arguments and scratch; R0 result; preserve R4-R11; save LR before nested BL; restore SP exactly; keep public call boundaries eight-byte aligned."]),
               ("Addressing",["byte index x1; halfword index x2; word index x4; row-major matrix index = row * columns + column."]),
               ("Signedness",["Use LDRSB/LDRSH and signed conditions for signed values. Use LDRB/LDRH and unsigned conditions for unsigned values."]),
               ("Interrupts",["Acknowledge the source, capture bounded state, publish a volatile event, and do longer work in foreground unless the paper says otherwise."]),
               ("Minimal-change checklist",["Change configuration first; keep the ABI; localize encoding/recurrence rules; rerun guards, boundaries, ABI checks, state timelines, simulator execution, and the hardware build."]),
               ("Lookup",[f"{tag}: {PATTERNS[tag][0]}" for tag,_ in counts.most_common()])]
    out=ATLAS/"documentation"; out.mkdir(parents=True,exist_ok=True)
    make_pdf(out/"ARM_EXAM_ATLAS_MASTER.pdf","ARM Exam Atlas - Master Reference",sections)
    make_pdf(out/"ARM_EXAM_QUICK_REFERENCE.pdf","ARM Exam Quick Reference",qsections)
    print(json.dumps({"questions":len(rows),"exams":len(by_exam),"projects":len(projects),"patterns":len(PATTERNS),"pdfs":2},indent=2))

if __name__ == "__main__": main()
