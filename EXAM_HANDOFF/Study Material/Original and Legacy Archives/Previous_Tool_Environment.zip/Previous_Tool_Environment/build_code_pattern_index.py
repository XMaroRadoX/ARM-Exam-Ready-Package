import csv
import json
import os
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ATLAS = ROOT / "ARM_EXAM_ATLAS"
KIT = ROOT / "deliverables" / "selected_arm_kit"
TEMPLATES = KIT / "templates"
PROJECTS = ROOT / "deliverables" / "solved_exam_examples"

# Pattern ID -> (canonical code, alternative code, short adaptation instruction).
CODE = {
 "PAT-ALG-SORTING-001": ("02_algorithms/array_scan_word.s", "../../solved_exam_examples/2023-02-07_Sort_FreeRunning_Timer/Source/exam/exam_asm.s", "Change element width/signed load, comparison condition, and length."),
 "PAT-ALG-RECURRENCE-001": ("02_algorithms/recurrence_into_array.s", "../../solved_exam_examples/2026-02-03_ARM3_Recaman_ADC_Timer/Source/exam/exam_asm.s", "Change the seed block and the one recurrence-rule block; keep the array ABI."),
 "PAT-ALG-GRAPH-SEARCH-001": ("02_algorithms/matrix_row_major_byte.s", "../../solved_exam_examples/2025-01-29_ARM2_Matrix_Two_Timers/Source/exam/exam_asm.s", "Keep row-major addressing; replace only neighbor/edge acceptance and termination policy."),
 "PAT-ALG-FREQUENCY-COUNT-001": ("../../solved_exam_examples/2026-06-25_ARM1_BullsAndCows/Source/exam/exam_asm.s", "../../solved_exam_examples/2026-06-25_ARM2_Mastermind/Source/exam/exam_asm.s", "Choose frequency counters for a small value range or used markers for general values."),
 "PAT-ALG-FIXED-POINT-001": ("02_algorithms/fixed_point_recurrence.s", "../../solved_exam_examples/2025-02-12_ARM1_Sine_DAC/Source/exam/exam_asm.s", "Change Q format and coefficients; recalculate the post-SMULL shift."),
 "PAT-FLOW-NESTED-LOOP-001": ("02_algorithms/nested_search_with_break.s", "02_algorithms/packed_bit_matrix.s", "Keep outer state in preserved registers and reset the inner index at each outer iteration."),
 "PAT-FLOW-EARLY-BREAK-001": ("02_algorithms/nested_search_with_break.s", "../../solved_exam_examples/2026-06-25_ARM2_Mastermind/Source/exam/exam_asm.s", "Branch to one named inner-loop exit; do not bypass stack restoration."),
 "PAT-MEM-BYTE-ARRAY-001": ("02_algorithms/matrix_row_major_byte.s", "02_algorithms/array_scan_word.s", "Use LDRB for unsigned bytes or LDRSB for signed bytes; index scale is one."),
 "PAT-MEM-WORD-ARRAY-001": ("02_algorithms/array_scan_word.s", "02_algorithms/recurrence_into_array.s", "Use LSL #2 scaled addressing and pass element count, not byte count."),
 "PAT-MEM-MATRIX-ROW-MAJOR-001": ("02_algorithms/matrix_row_major_byte.s", "02_algorithms/packed_bit_matrix.s", "Compute row * columns + column, then apply the element-size or packed-bit transform."),
 "PAT-AAPCS-FOUR-ARGS-001": ("../../solved_exam_examples/2026-06-25_ARM1_BullsAndCows/Source/exam/exam_asm.s", "../../solved_exam_examples/2026-06-25_ARM2_Mastermind/Source/exam/exam_asm.s", "Move long-lived R0-R3 pointers into preserved registers before reusing argument registers."),
 "PAT-AAPCS-STACKED-ARGS-001": ("01_aapcs/five_to_seven_arguments.s", "01_aapcs/nonleaf_function.s", "Capture the caller's original SP before PUSH and calculate offsets from that value."),
 "PAT-AAPCS-NONLEAF-001": ("01_aapcs/nonleaf_function.s", "../../solved_exam_examples/2023-07-04_Sociable_Timer/Source/exam/exam_asm.s", "Save LR before the first BL and save an even total number of registers."),
 "PAT-CPU-FLAGS-001": ("04_rare_dangerous/apsr_flags.s", "04_rare_dangerous/two_word_arithmetic.s", "Use the S-suffixed arithmetic instruction that naturally creates the required flags."),
 "PAT-CPU-SVC-001": ("04_rare_dangerous/svc_handler.s", "04_rare_dangerous/reset_handler.s", "Decode the byte at stacked PC-2 and write return values into the stacked frame."),
 "PAT-CPU-EXCEPTION-FRAME-001": ("04_rare_dangerous/svc_handler.s", "04_rare_dangerous/reset_handler.s", "Test EXC_RETURN bit 2 before selecting MSP or PSP; preserve EXC_RETURN in LR."),
 "PAT-TIMER-OWNERSHIP-001": ("03_board/periodic_timer.c", "03_board/multi_timer_state.c", "Assign each timer/vector once and keep the callback bounded."),
 "PAT-GPIO-EVENT-001": ("03_board/button_debounce_event.c", "03_board/joystick_state_machine.c", "Publish an event in the callback and consume it once in foreground."),
 "PAT-GPIO-JOYSTICK-001": ("03_board/joystick_state_machine.c", "03_board/button_debounce_event.c", "Change the transition table and display policy, not the debounce/event plumbing."),
 "PAT-ADC-SAMPLE-001": ("03_board/adc_to_leds.c", "03_board/joystick_state_machine.c", "Normalize the 12-bit sample once, then pass the value to a small policy function."),
 "PAT-DAC-STREAM-001": ("03_board/dac_table_stream.c", "03_board/multi_timer_state.c", "Change sample table and period; keep the ISR index bounded and wrap explicitly."),
 "PAT-STATE-EVENT-LOOP-001": ("03_board/joystick_state_machine.c", "03_board/periodic_timer.c", "Callbacks only set bits/data; the foreground loop owns algorithm calls and display changes."),
 "PAT-STATE-DEBOUNCE-001": ("03_board/button_debounce_event.c", "03_board/joystick_state_machine.c", "Change confirmation ticks in configuration; retain press and release edges."),
 "PAT-TIMER-PERIODIC-001": ("03_board/periodic_timer.c", "03_board/multi_timer_state.c", "Change the millisecond period and timer ID in the configuration call."),
 "PAT-TIMER-FREE-RUNNING-001": ("03_board/free_running_timer.c", "03_board/periodic_timer.c", "Use the counter as a seed/capture and do not enable the match interrupt unless required."),
 "PAT-AAPCS-STACK-SAFETY-001": ("01_aapcs/nonleaf_function.s", "01_aapcs/five_to_seven_arguments.s", "Preserve R4-R11, save LR before BL, and push an even register count."),
 "PAT-STATE-IRQ-HANDOFF-001": ("03_board/periodic_timer.c", "03_board/button_debounce_event.c", "Make shared events volatile/atomic through the kit API and take them once in foreground."),
 "PAT-TIMER-VECTOR-OWNERSHIP-001": ("03_board/multi_timer_state.c", "04_rare_dangerous/systick_raw.s", "Select exactly one owner per IRQ handler and clear only that peripheral's pending source."),
}

def resolve(value: str) -> Path:
    if value.startswith("../../solved_exam_examples/"):
        return ROOT / "deliverables" / value[6:]
    return TEMPLATES / value

def display(value: str) -> str:
    return os.path.relpath(resolve(value), ATLAS).replace("\\", "/")

def main():
    with (ATLAS/"indexes"/"patterns.csv").open(encoding="utf-8-sig") as f:
        patterns = list(csv.DictReader(f))
    questions = list(csv.DictReader((ATLAS/"indexes"/"questions.csv").open(encoding="utf-8-sig")))
    by_exam = defaultdict(list)
    for q in questions: by_exam[q["exam_id"]].append(q)
    catalog=[]
    lines=["# Code-first exam pattern index","",
           "These are actual source files to copy and adapt. Start with the canonical code, read its contract comments, then change only the listed adaptation points.","",
           "| I see this question shape | Canonical code | Alternative | Change first |","|---|---|---|---|"]
    for p in patterns:
        pid=p["pattern_id"]; primary,alt,change=CODE[pid]
        primary_path=resolve(primary); alt_path=resolve(alt)
        status="COMPILED_CODE" if primary_path.is_file() else "MISSING"
        lines.append(f"| `{p['primary_tag']}` - {p['title']} | [{primary_path.name}]({display(primary)}) | [{alt_path.name}]({display(alt)}) | {change} |")
        catalog.append({"pattern_id":pid,"tag":p["primary_tag"],"title":p["title"],"canonical_code":str(primary_path),"alternative_code":str(alt_path),"adaptation":change,"status":status})
        page=ATLAS/"patterns"/p["category"]/(pid+".md")
        old=page.read_text(encoding="utf-8") if page.exists() else f"# {pid}\n"
        code_section=f"""

## Start with actual code

- Canonical: [`{primary_path.name}`]({os.path.relpath(primary_path,page.parent).replace(os.sep,'/')})
- Alternative: [`{alt_path.name}`]({os.path.relpath(alt_path,page.parent).replace(os.sep,'/')})
- Code status: `{status}`

## Change these lines first

{change}

The linked source is the pattern. This page is navigation and adaptation guidance, not a substitute for the code.
"""
        if "## Start with actual code" in old: old=old.split("## Start with actual code")[0].rstrip()
        page.write_text(old+code_section,encoding="utf-8")
    (ATLAS/"CODE_PATTERN_INDEX.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    with (ATLAS/"indexes"/"code_pattern_catalog.csv").open("w",newline="",encoding="utf-8-sig") as f:
        w=csv.DictWriter(f,fieldnames=list(catalog[0]));w.writeheader();w.writerows(catalog)
    # Give every exam a code-first route based on its linked pattern IDs.
    for exam_id,qrows in by_exam.items():
        year=exam_id[1:5]; folder=ATLAS/"exams"/year/exam_id[1:]
        out=[f"# {exam_id} - code start here",""]
        seen=set()
        for q in qrows:
            out += [f"## {q['question_id']}","",q["requirement"],""]
            for pid in filter(None,q["pattern_ids"].split(";")):
                if pid in seen: continue
                seen.add(pid); primary,alt,change=CODE[pid]
                out += [f"- `{pid}`: [{Path(primary).name}]({os.path.relpath(resolve(primary),folder).replace(os.sep,'/')}) - {change}"]
            out.append("")
        (folder/"CODE_START_HERE.md").write_text("\n".join(out)+"\n",encoding="utf-8")
    index=ATLAS/"INDEX.md"; text=index.read_text(encoding="utf-8")
    marker="Start with [Code-First Pattern Index](CODE_PATTERN_INDEX.md) when you need source to adapt."
    if marker not in text: text=text.replace("Start with ",marker+"\n\nStart with ",1)
    index.write_text(text,encoding="utf-8")
    print(json.dumps({"code_patterns":len(catalog),"compiled_links":sum(x['status']=='COMPILED_CODE' for x in catalog),"exam_code_routes":len(by_exam)},indent=2))

if __name__ == "__main__": main()
