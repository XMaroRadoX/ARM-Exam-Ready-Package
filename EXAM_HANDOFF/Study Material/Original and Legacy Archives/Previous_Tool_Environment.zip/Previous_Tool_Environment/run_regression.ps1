param(
  [switch]$SkipKeil
)

$ErrorActionPreference = 'Stop'
$package = Split-Path -Parent $PSScriptRoot
$projectsRoot = Join-Path $package 'deliverables\solved_exam_examples'
$resultsRoot = Join-Path $package 'deliverables\verification'
New-Item -ItemType Directory -Path $resultsRoot -Force | Out-Null

$gcc = (Get-Command gcc -ErrorAction Stop).Source
$uv4 = 'C:\Users\marwa\AppData\Local\Keil_v5\UV4\UV4.exe'
$rows = @()

foreach ($project in Get-ChildItem -LiteralPath $projectsRoot -Directory | Sort-Object Name) {
  $buildDir = Join-Path $project.FullName 'Build\AutomatedTests'
  New-Item -ItemType Directory -Path $buildDir -Force | Out-Null
  $simExe = Join-Path $buildDir 'simulated_board_tests.exe'
  $hostExe = Join-Path $buildDir 'host_logic_tests.exe'
  $simStatus = 'FAIL'
  $hostStatus = 'NOT_PRESENT'
  $hardwareStatus = if ($SkipKeil) { 'NOT_RUN' } else { 'FAIL' }

  & $gcc -std=c11 -Wall -Wextra -Werror `
    (Join-Path $project.FullName 'Simulation\simulator_main.c') `
    (Join-Path $project.FullName 'Simulation\simulated_board.c') `
    -I (Join-Path $project.FullName 'Simulation') -o $simExe
  if ($LASTEXITCODE -eq 0) {
    & $simExe
    if ($LASTEXITCODE -eq 0) { $simStatus = 'SIMULATED_PERIPHERAL_MODEL_PASS' }
  }

  $hostSource = Join-Path $project.FullName 'Tests\host_logic_tests.c'
  if (Test-Path -LiteralPath $hostSource) {
    & $gcc -std=c11 -Wall -Wextra -Werror $hostSource -o $hostExe
    if ($LASTEXITCODE -eq 0) {
      & $hostExe
      if ($LASTEXITCODE -eq 0) { $hostStatus = 'HOST_REFERENCE_PASS' } else { $hostStatus = 'FAIL' }
    } else { $hostStatus = 'FAIL' }
  }

  $log = Join-Path $buildDir 'keil_build.log'
  if (-not $SkipKeil) {
    $uvproj = Get-ChildItem -LiteralPath $project.FullName -File -Filter *.uvprojx | Select-Object -First 1
    if ($null -ne $uvproj) {
      $proc = Start-Process -FilePath $uv4 -ArgumentList @('-b', $uvproj.FullName, '-o', $log) -WindowStyle Hidden -Wait -PassThru
      if ($proc.ExitCode -eq 0 -and (Test-Path -LiteralPath $log)) {
        $text = Get-Content -LiteralPath $log -Raw
        if ($text -match '0 Error\(s\), 0 Warning\(s\)') { $hardwareStatus = 'HARDWARE_BUILD_PASS' }
      }
    }
  }

  $rows += [pscustomobject]@{
    project = $project.Name
    peripheral_model = $simStatus
    host_reference = $hostStatus
    hardware_build = $hardwareStatus
    arm_instruction_execution = 'COMPILE_ONLY'
    physical_board = 'PHYSICAL_BOARD_NOT_TESTED'
  }
}

$csv = Join-Path $resultsRoot 'REGRESSION_SUMMARY.csv'
$rows | Export-Csv -LiteralPath $csv -NoTypeInformation -Encoding utf8
$passedModels = ($rows | Where-Object peripheral_model -eq 'SIMULATED_PERIPHERAL_MODEL_PASS').Count
$passedHost = ($rows | Where-Object host_reference -eq 'HOST_REFERENCE_PASS').Count
$passedHardware = ($rows | Where-Object hardware_build -eq 'HARDWARE_BUILD_PASS').Count
$report = @"
# Automated regression summary

| Check | Passed | Total |
|---|---:|---:|
| Deterministic peripheral model | $passedModels | $($rows.Count) |
| Host reference tests | $passedHost | $($rows.Count) |
| LPC1768 hardware build | $passedHardware | $($rows.Count) |
| Actual ARM instruction execution | 0 | $($rows.Count) |

The peripheral model tests execute native C simulations. Host tests execute independent C reference calculations. Hardware builds compile and link the actual LPC1768/ARM sources. Actual ARM instruction execution remains `COMPILE_ONLY` until a Keil simulator target runs the linked assembly harness; it is not inferred from either C test category.

Physical status for every project is `PHYSICAL_BOARD_NOT_TESTED`.
"@
Set-Content -LiteralPath (Join-Path $resultsRoot 'REGRESSION_SUMMARY.md') -Value $report -Encoding utf8
$rows | Format-Table -AutoSize
if ($passedModels -ne $rows.Count -or $passedHardware -ne $rows.Count) { exit 1 }
