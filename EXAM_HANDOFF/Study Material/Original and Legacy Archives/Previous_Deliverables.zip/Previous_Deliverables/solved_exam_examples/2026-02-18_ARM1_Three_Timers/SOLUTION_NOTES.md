# 18 February 2026 ARM1 solution map

- `HofstadterQ` in `Source/exam/exam_asm.s` solves question 1.
- `Source/exam/exam_user.c` solves question 2.
- Timer0 is A, Timer1 is B and Timer2 is C.
- All three timer ownership switches are already enabled.
- Fit JP2 when checking the speaker on the LandTiger board.
