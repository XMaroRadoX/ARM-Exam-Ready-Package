# 3 February 2026 ARM2 solution map

- The foreground continuously shows the ADC's upper eight bits.
- The normal confirmed-button system provides physical debouncing.
- KEY1 passes the cached value to `run_length_encoding`.
- Fit JP12 when testing the potentiometer on the physical board.
