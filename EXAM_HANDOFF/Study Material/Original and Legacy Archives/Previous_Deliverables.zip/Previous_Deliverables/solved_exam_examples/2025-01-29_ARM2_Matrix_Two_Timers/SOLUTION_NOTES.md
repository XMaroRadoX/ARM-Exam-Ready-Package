# 29 January 2025 ARM2 solution map

- The assembly routine performs an 8x8 bit-matrix multiplication.
- INT0 fills one row of A and B from Timer1's low 16 bits.
- Timer1 resets at `0xFFFF` without generating an interrupt.
- KEY1 starts the multiplication only after eight rows have been captured.
- Timer0 displays each result row for exactly 0.5 seconds, then turns LEDs off.
