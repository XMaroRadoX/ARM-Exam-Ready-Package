ULTIMATE CA EXAM TEMPLATE v2
============================

OPEN THIS PROJECT
  Ultimate_CA_Template_v2.uvprojx

USE ONE TARGET
  The project contains one target: CA Exam.

NORMAL WORKFLOW
  1. Edit Source\exam\exam_user.c for C.
  2. Edit Source\exam\exam_asm.s for ARM assembly.
  3. Build the same CA Exam target.
  4. Fix the first error before reading later errors.

YOU DO NOT CHOOSE BETWEEN DIFFERENT ANSWER TYPES
  Checked exam_* functions, familiar course function names, direct LPC1768
  registers, callbacks, exact interrupt handlers, SVC work, and self-tests
  are all available in the same project.

WHEN THE QUESTION REQUIRES AN EXACT HANDLER
  Open Source\platform\exam_config.h and set only the matching
  EXAM_OWN_*_HANDLER switch to 1. Then write that handler in exam_user.c.
  This prevents two files from defining the same vector.

BOARD REMINDERS
  LEDs: printed numbers 4..11.
  External buttons: INT0, KEY1 and KEY2 are active-low.
  Potentiometer: fit JP12.
  Speaker/analog output: fit JP2.

READ NEXT
  Documentation\PERIPHERAL_RECIPES.md
  Documentation\TEMPLATE_GUIDE.md
  Documentation\API_REFERENCE.md
