# 12 February 2025 ARM1 solution map

- INT0 starts Timer0 once; no button debouncing is used, as required.
- Timer0 interrupts every 1263 peripheral-clock cycles.
- `sineValues[45]` is a visible global as required by the paper.
- Each handler call evaluates the assembly Maclaurin routine and updates the DAC.
