# 1 July 2025 ARM1 solution map

- The assembly function demonstrates the fifth argument at the caller's SP.
- `Reset_Handler` fills the required test array and then branches to `__main`.
- Timer0 produces one LCG value every three seconds, for ten intervals.
- Only the first non-zero joystick movement in each interval is counted.
- LEDs 4 and 5 show the final win/loss result.
