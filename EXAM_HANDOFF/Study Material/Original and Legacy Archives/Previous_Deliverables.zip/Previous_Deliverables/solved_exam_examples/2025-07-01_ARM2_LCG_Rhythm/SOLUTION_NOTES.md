# 1 July 2025 ARM2 solution map

- `LCGsequence` reads its fifth argument from the stack.
- Timer1 produces one value every 2.5 seconds, for ten intervals.
- Only the first joystick movement in each interval is counted.
- LEDs 10 and 11 show the final win/loss result.
