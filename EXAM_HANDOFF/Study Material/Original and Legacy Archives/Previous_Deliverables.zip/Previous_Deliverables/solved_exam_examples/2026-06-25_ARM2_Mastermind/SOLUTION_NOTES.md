# Mastermind solution notes

- Q1 uses four pointer arguments and two passes.
- The first pass marks exact matches. The second uses a nested scan and breaks immediately after marking one available partial match.
- The assembly routine saves R4-R11 and uses one balanced ten-register frame.
- C clears `usedGuess` and `usedSecret` before every attempt.
- Timer1 is sampled only at the first joystick-select event; later guesses keep the same secret.
- The LED packing is identical to the paper; only the joystick-direction-to-digit mapping differs from ARM1.
- The formula is `((2^exact - 1) << 4) + (2^partial - 1)`; the PDF's superscript can disappear during text extraction.
- The high result nibble equals fifteen when all four digits are exact, which enters the finished state.

Build the only `CA Exam` target. Physical acceptance requires the LandTiger board and confirmed joystick operation.
