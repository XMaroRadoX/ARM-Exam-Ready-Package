#include <assert.h>
#include <stdint.h>
#include <stdio.h>

static int reference_mastermind(const int guess[4], const int secret[4]) {
    int ug[4] = {0, 0, 0, 0};
    int us[4] = {0, 0, 0, 0};
    int exact = 0;
    int partial = 0;
    int i;
    int j;

    for (i = 0; i < 4; ++i) {
        if (guess[i] == secret[i]) {
            ++exact;
            ug[i] = 1;
            us[i] = 1;
        }
    }
    for (i = 0; i < 4; ++i) {
        for (j = 0; j < 4; ++j) {
            if (!ug[i] && !us[j] && guess[i] == secret[j]) {
                ++partial;
                ug[i] = 1;
                us[j] = 1;
                break;
            }
        }
    }
    return (int)((((1u << (uint32_t)exact) - 1u) << 4) +
                 ((1u << (uint32_t)partial) - 1u));
}

int main(void) {
    const int example_g[4] = {0, 1, 2, 3};
    const int example_s[4] = {1, 2, 2, 0};
    const int exact_g[4] = {0, 1, 2, 3};
    const int exact_s[4] = {0, 1, 2, 3};
    const int none_g[4] = {0, 0, 0, 0};
    const int none_s[4] = {3, 3, 3, 3};
    const int repeated_g[4] = {1, 1, 1, 1};
    const int repeated_s[4] = {1, 2, 2, 2};

    assert(reference_mastermind(example_g, example_s) == 19);
    assert(reference_mastermind(exact_g, exact_s) == 0xF0);
    assert(reference_mastermind(none_g, none_s) == 0x00);
    assert(reference_mastermind(repeated_g, repeated_s) == 0x10);
    puts("Mastermind reference tests passed");
    return 0;
}
