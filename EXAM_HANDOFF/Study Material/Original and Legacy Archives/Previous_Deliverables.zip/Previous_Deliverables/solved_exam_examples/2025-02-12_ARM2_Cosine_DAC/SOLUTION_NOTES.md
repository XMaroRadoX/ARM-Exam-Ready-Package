# 12 February 2025 ARM2 solution map

- KEY1 starts Timer1 once; no button debouncing is used, as required.
- Timer1 interrupts every 1592 peripheral-clock cycles.
- `cosineValues[45]` is a visible global as required by the paper.
- Each handler call evaluates `Maclaurin_cos` and updates the DAC.
