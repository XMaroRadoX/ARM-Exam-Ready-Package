# API reference

## Main functions

| Function | Use | Important condition |
|---|---|---|
| `exam_init()` | Initialize the board support once. | Call before other helpers. |
| `exam_led_on/off/toggle(4..11)` | Control one printed LED number. | Printed number, not GPIO bit number. |
| `exam_led_write(mask)` | Show an 8-bit result. | Bit 0 is P2.0. |
| `exam_buttons_start(callback)` | Receive confirmed INT0/KEY1/KEY2 events. | Keep the callback short. |
| `exam_button_pressed(button)` | Poll one active-low button. | Returns 1 while held. |
| `exam_joystick_start(callback)` | Receive changed joystick masks. | Test masks with `&`. |
| `exam_joystick_first()` | Read the first nonzero movement. | Reset before a new trial. |
| `exam_timer_every_ms(t, ms, cb)` | Start a periodic timer quickly. | Timer 0..3; ms is positive. |
| `exam_timer_every_hz(t, hz, cb)` | Start one callback per cycle. | Set divider/PR first if required. |
| `exam_timer_match(...)` | Configure MR and MCR actions. | Value is timer ticks. |
| `exam_timer_count(t)` | Read a free-running counter. | Start the timer first. |
| `exam_rit_start()` | Start the 10 ms scheduler. | Default RIT setting only. |
| `exam_systick_every_ms(ms)` | Start periodic SysTick. | Use when SysTick is requested. |
| `exam_pot_start/read()` | Read fresh potentiometer samples. | Fit JP12; range 0..4095. |
| `exam_dac_write(value)` | Write one 10-bit sample. | Fit JP2; range 0..1023. |
| `exam_events_set/take(bits)` | Pass work from a callback to main. | Give every event one unique bit. |
| `exam_critical_enter/exit()` | Protect a short shared update. | Pass the saved value back unchanged. |
| `exam_self_test()` | Run automatic configuration checks. | Zero means no automatic failure. |

## Familiar course functions

`exam_compat.h` provides `LED_init`, `LED_On`, `LED_Off`, `LED_Out`, `BUTTON_init`, `init_timer`, `enable_timer`, `disable_timer`, `reset_timer`, `init_RIT`, `enable_RIT`, `disable_RIT`, `reset_RIT`, `ADC_init`, and `ADC_start_conversion`.

## Status values

| Value | Meaning |
|---|---|
| `EXAM_OK` | Success. |
| `EXAM_INVALID` | Null pointer or invalid combination. |
| `EXAM_BUSY` | A resource or mode conflicts with the request. |
| `EXAM_RANGE` | A number is outside its allowed range. |
| `EXAM_NOT_READY` | No fresh result exists yet. |
