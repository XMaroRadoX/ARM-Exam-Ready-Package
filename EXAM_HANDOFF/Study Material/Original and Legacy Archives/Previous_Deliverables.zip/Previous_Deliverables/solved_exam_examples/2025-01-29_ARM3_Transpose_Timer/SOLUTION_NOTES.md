# 29 January 2025 ARM3 solution map

- The assembly routine transposes an 8x8 bit matrix.
- Timer2 resets at `0xFFFF` without a timer interrupt.
- KEY1 fills A; KEY2 fills B; later presses are ignored after eight values.
- INT0 calls `transpose` three times and checks `(A XOR B)T = AT XOR BT`.
