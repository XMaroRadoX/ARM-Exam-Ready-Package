# 3 February 2026 ARM1 solution map

- The foreground continuously shows the ADC's upper eight bits.
- The normal confirmed-button system provides physical debouncing.
- INT0 passes the cached eight-bit value to `Look_and_Say`.
- Fit JP12 when testing the potentiometer on the physical board.
