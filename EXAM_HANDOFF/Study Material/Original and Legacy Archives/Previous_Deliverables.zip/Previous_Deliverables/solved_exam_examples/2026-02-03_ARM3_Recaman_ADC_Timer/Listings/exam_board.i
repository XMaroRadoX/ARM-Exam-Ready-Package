# 1 "Source/platform/exam_board.c"
# 1 "<built-in>" 1
# 1 "<built-in>" 3
# 393 "<built-in>" 3
# 1 "<command line>" 1
# 1 "<built-in>" 2
# 1 "Source/platform/exam_board.c" 2
# 1 "Source/platform\\exam_board.h" 1



# 1 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdint.h" 1 3
# 56 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdint.h" 3
typedef signed char int8_t;
typedef signed short int int16_t;
typedef signed int int32_t;
typedef signed long long int int64_t;


typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long long int uint64_t;





typedef signed char int_least8_t;
typedef signed short int int_least16_t;
typedef signed int int_least32_t;
typedef signed long long int int_least64_t;


typedef unsigned char uint_least8_t;
typedef unsigned short int uint_least16_t;
typedef unsigned int uint_least32_t;
typedef unsigned long long int uint_least64_t;




typedef signed int int_fast8_t;
typedef signed int int_fast16_t;
typedef signed int int_fast32_t;
typedef signed long long int int_fast64_t;


typedef unsigned int uint_fast8_t;
typedef unsigned int uint_fast16_t;
typedef unsigned int uint_fast32_t;
typedef unsigned long long int uint_fast64_t;






typedef signed int intptr_t;
typedef unsigned int uintptr_t;



typedef signed long long intmax_t;
typedef unsigned long long uintmax_t;
# 5 "Source/platform\\exam_board.h" 2
# 1 "C:/Users/marwa/AppData/Local/Arm/Packs/Keil/LPC1700_DFP/2.7.2/Device/Include\\LPC17xx.h" 1
# 41 "C:/Users/marwa/AppData/Local/Arm/Packs/Keil/LPC1700_DFP/2.7.2/Device/Include\\LPC17xx.h"
typedef enum IRQn
{

  Reset_IRQn = -15,
  NonMaskableInt_IRQn = -14,
  HardFault_IRQn = -13,
  MemoryManagement_IRQn = -12,
  BusFault_IRQn = -11,
  UsageFault_IRQn = -10,
  SVCall_IRQn = -5,
  DebugMonitor_IRQn = -4,
  PendSV_IRQn = -2,
  SysTick_IRQn = -1,


  WDT_IRQn = 0,
  TIMER0_IRQn = 1,
  TIMER1_IRQn = 2,
  TIMER2_IRQn = 3,
  TIMER3_IRQn = 4,
  UART0_IRQn = 5,
  UART1_IRQn = 6,
  UART2_IRQn = 7,
  UART3_IRQn = 8,
  PWM1_IRQn = 9,
  I2C0_IRQn = 10,
  I2C1_IRQn = 11,
  I2C2_IRQn = 12,
  SPI_IRQn = 13,
  SSP0_IRQn = 14,
  SSP1_IRQn = 15,
  PLL0_IRQn = 16,
  RTC_IRQn = 17,
  EINT0_IRQn = 18,
  EINT1_IRQn = 19,
  EINT2_IRQn = 20,
  EINT3_IRQn = 21,
  ADC_IRQn = 22,
  BOD_IRQn = 23,
  USB_IRQn = 24,
  CAN_IRQn = 25,
  DMA_IRQn = 26,
  I2S_IRQn = 27,
  ENET_IRQn = 28,
  RIT_IRQn = 29,
  MCPWM_IRQn = 30,
  QEI_IRQn = 31,
  PLL1_IRQn = 32,
  USBActivity_IRQn = 33,
  CANActivity_IRQn = 34,
} IRQn_Type;
# 106 "C:/Users/marwa/AppData/Local/Arm/Packs/Keil/LPC1700_DFP/2.7.2/Device/Include\\LPC17xx.h"
# 1 "./Source/CMSIS_core\\core_cm3.h" 1
# 29 "./Source/CMSIS_core\\core_cm3.h" 3
# 63 "./Source/CMSIS_core\\core_cm3.h" 3
# 1 "./Source/CMSIS_core\\cmsis_version.h" 1 3
# 29 "./Source/CMSIS_core\\cmsis_version.h" 3
# 64 "./Source/CMSIS_core\\core_cm3.h" 2 3
# 115 "./Source/CMSIS_core\\core_cm3.h" 3
# 1 "./Source/CMSIS_core\\cmsis_compiler.h" 1 3
# 47 "./Source/CMSIS_core\\cmsis_compiler.h" 3
# 1 "./Source/CMSIS_core\\cmsis_armclang.h" 1 3
# 31 "./Source/CMSIS_core\\cmsis_armclang.h" 3
# 64 "./Source/CMSIS_core\\cmsis_armclang.h" 3
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpacked"

  struct __attribute__((packed)) T_UINT32 { uint32_t v; };
#pragma clang diagnostic pop



#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpacked"

  struct __attribute__((packed, aligned(1))) T_UINT16_WRITE { uint16_t v; };
#pragma clang diagnostic pop



#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpacked"

  struct __attribute__((packed, aligned(1))) T_UINT16_READ { uint16_t v; };
#pragma clang diagnostic pop



#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpacked"

  struct __attribute__((packed, aligned(1))) T_UINT32_WRITE { uint32_t v; };
#pragma clang diagnostic pop



#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wpacked"

  struct __attribute__((packed, aligned(1))) T_UINT32_READ { uint32_t v; };
#pragma clang diagnostic pop
# 260 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline uint32_t __ROR(uint32_t op1, uint32_t op2)
{
  op2 %= 32U;
  if (op2 == 0U)
  {
    return op1;
  }
  return (op1 >> op2) | (op1 << (32U - op2));
}
# 295 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline uint8_t __CLZ(uint32_t value)
{
# 306 "./Source/CMSIS_core\\cmsis_armclang.h" 3
  if (value == 0U)
  {
    return 32U;
  }
  return __builtin_clz(value);
}
# 425 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline uint32_t __RRX(uint32_t value)
{
  uint32_t result;

  __asm volatile ("rrx %0, %1" : "=r" (result) : "r" (value) );
  return(result);
}
# 440 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline uint8_t __LDRBT(volatile uint8_t *ptr)
{
  uint32_t result;

  __asm volatile ("ldrbt %0, %1" : "=r" (result) : "Q" (*ptr) );
  return ((uint8_t) result);
}
# 455 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline uint16_t __LDRHT(volatile uint16_t *ptr)
{
  uint32_t result;

  __asm volatile ("ldrht %0, %1" : "=r" (result) : "Q" (*ptr) );
  return ((uint16_t) result);
}
# 470 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline uint32_t __LDRT(volatile uint32_t *ptr)
{
  uint32_t result;

  __asm volatile ("ldrt %0, %1" : "=r" (result) : "Q" (*ptr) );
  return(result);
}
# 485 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __STRBT(uint8_t value, volatile uint8_t *ptr)
{
  __asm volatile ("strbt %1, %0" : "=Q" (*ptr) : "r" ((uint32_t)value) );
}
# 497 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __STRHT(uint16_t value, volatile uint16_t *ptr)
{
  __asm volatile ("strht %1, %0" : "=Q" (*ptr) : "r" ((uint32_t)value) );
}
# 509 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __STRT(uint32_t value, volatile uint32_t *ptr)
{
  __asm volatile ("strt %1, %0" : "=Q" (*ptr) : "r" (value) );
}
# 737 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __enable_irq(void)
{
  __asm volatile ("cpsie i" : : : "memory");
}
# 750 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __disable_irq(void)
{
  __asm volatile ("cpsid i" : : : "memory");
}
# 762 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline uint32_t __get_CONTROL(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, control" : "=r" (result) );
  return(result);
}
# 792 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __set_CONTROL(uint32_t control)
{
  __asm volatile ("MSR control, %0" : : "r" (control) : "memory");
  __builtin_arm_isb(0xF);
}
# 818 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline uint32_t __get_IPSR(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, ipsr" : "=r" (result) );
  return(result);
}







__attribute__((always_inline)) static __inline uint32_t __get_APSR(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, apsr" : "=r" (result) );
  return(result);
}







__attribute__((always_inline)) static __inline uint32_t __get_xPSR(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, xpsr" : "=r" (result) );
  return(result);
}







__attribute__((always_inline)) static __inline uint32_t __get_PSP(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, psp" : "=r" (result) );
  return(result);
}
# 890 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __set_PSP(uint32_t topOfProcStack)
{
  __asm volatile ("MSR psp, %0" : : "r" (topOfProcStack) : );
}
# 914 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline uint32_t __get_MSP(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, msp" : "=r" (result) );
  return(result);
}
# 944 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __set_MSP(uint32_t topOfMainStack)
{
  __asm volatile ("MSR msp, %0" : : "r" (topOfMainStack) : );
}
# 995 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline uint32_t __get_PRIMASK(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, primask" : "=r" (result) );
  return(result);
}
# 1025 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __set_PRIMASK(uint32_t priMask)
{
  __asm volatile ("MSR primask, %0" : : "r" (priMask) : "memory");
}
# 1053 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __enable_fault_irq(void)
{
  __asm volatile ("cpsie f" : : : "memory");
}







__attribute__((always_inline)) static __inline void __disable_fault_irq(void)
{
  __asm volatile ("cpsid f" : : : "memory");
}







__attribute__((always_inline)) static __inline uint32_t __get_BASEPRI(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, basepri" : "=r" (result) );
  return(result);
}
# 1105 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __set_BASEPRI(uint32_t basePri)
{
  __asm volatile ("MSR basepri, %0" : : "r" (basePri) : "memory");
}
# 1130 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __set_BASEPRI_MAX(uint32_t basePri)
{
  __asm volatile ("MSR basepri_max, %0" : : "r" (basePri) : "memory");
}







__attribute__((always_inline)) static __inline uint32_t __get_FAULTMASK(void)
{
  uint32_t result;

  __asm volatile ("MRS %0, faultmask" : "=r" (result) );
  return(result);
}
# 1171 "./Source/CMSIS_core\\cmsis_armclang.h" 3
__attribute__((always_inline)) static __inline void __set_FAULTMASK(uint32_t faultMask)
{
  __asm volatile ("MSR faultmask, %0" : : "r" (faultMask) : "memory");
}
# 48 "./Source/CMSIS_core\\cmsis_compiler.h" 2 3
# 116 "./Source/CMSIS_core\\core_cm3.h" 2 3
# 211 "./Source/CMSIS_core\\core_cm3.h" 3
typedef union
{
  struct
  {
    uint32_t _reserved0:27;
    uint32_t Q:1;
    uint32_t V:1;
    uint32_t C:1;
    uint32_t Z:1;
    uint32_t N:1;
  } b;
  uint32_t w;
} APSR_Type;
# 245 "./Source/CMSIS_core\\core_cm3.h" 3
typedef union
{
  struct
  {
    uint32_t ISR:9;
    uint32_t _reserved0:23;
  } b;
  uint32_t w;
} IPSR_Type;
# 263 "./Source/CMSIS_core\\core_cm3.h" 3
typedef union
{
  struct
  {
    uint32_t ISR:9;
    uint32_t _reserved0:1;
    uint32_t ICI_IT_1:6;
    uint32_t _reserved1:8;
    uint32_t T:1;
    uint32_t ICI_IT_2:2;
    uint32_t Q:1;
    uint32_t V:1;
    uint32_t C:1;
    uint32_t Z:1;
    uint32_t N:1;
  } b;
  uint32_t w;
} xPSR_Type;
# 314 "./Source/CMSIS_core\\core_cm3.h" 3
typedef union
{
  struct
  {
    uint32_t nPRIV:1;
    uint32_t SPSEL:1;
    uint32_t _reserved1:30;
  } b;
  uint32_t w;
} CONTROL_Type;
# 345 "./Source/CMSIS_core\\core_cm3.h" 3
typedef struct
{
  volatile uint32_t ISER[8U];
        uint32_t RESERVED0[24U];
  volatile uint32_t ICER[8U];
        uint32_t RESERVED1[24U];
  volatile uint32_t ISPR[8U];
        uint32_t RESERVED2[24U];
  volatile uint32_t ICPR[8U];
        uint32_t RESERVED3[24U];
  volatile uint32_t IABR[8U];
        uint32_t RESERVED4[56U];
  volatile uint8_t IP[240U];
        uint32_t RESERVED5[644U];
  volatile uint32_t STIR;
} NVIC_Type;
# 379 "./Source/CMSIS_core\\core_cm3.h" 3
typedef struct
{
  volatile const uint32_t CPUID;
  volatile uint32_t ICSR;
  volatile uint32_t VTOR;
  volatile uint32_t AIRCR;
  volatile uint32_t SCR;
  volatile uint32_t CCR;
  volatile uint8_t SHP[12U];
  volatile uint32_t SHCSR;
  volatile uint32_t CFSR;
  volatile uint32_t HFSR;
  volatile uint32_t DFSR;
  volatile uint32_t MMFAR;
  volatile uint32_t BFAR;
  volatile uint32_t AFSR;
  volatile const uint32_t PFR[2U];
  volatile const uint32_t DFR;
  volatile const uint32_t ADR;
  volatile const uint32_t MMFR[4U];
  volatile const uint32_t ISAR[5U];
        uint32_t RESERVED0[5U];
  volatile uint32_t CPACR;
} SCB_Type;
# 660 "./Source/CMSIS_core\\core_cm3.h" 3
typedef struct
{
        uint32_t RESERVED0[1U];
  volatile const uint32_t ICTR;



        uint32_t RESERVED1[1U];

} SCnSCB_Type;
# 706 "./Source/CMSIS_core\\core_cm3.h" 3
typedef struct
{
  volatile uint32_t CTRL;
  volatile uint32_t LOAD;
  volatile uint32_t VAL;
  volatile const uint32_t CALIB;
} SysTick_Type;
# 758 "./Source/CMSIS_core\\core_cm3.h" 3
typedef struct
{
  volatile union
  {
    volatile uint8_t u8;
    volatile uint16_t u16;
    volatile uint32_t u32;
  } PORT [32U];
        uint32_t RESERVED0[864U];
  volatile uint32_t TER;
        uint32_t RESERVED1[15U];
  volatile uint32_t TPR;
        uint32_t RESERVED2[15U];
  volatile uint32_t TCR;
        uint32_t RESERVED3[32U];
        uint32_t RESERVED4[43U];
  volatile uint32_t LAR;
  volatile const uint32_t LSR;
        uint32_t RESERVED5[6U];
  volatile const uint32_t PID4;
  volatile const uint32_t PID5;
  volatile const uint32_t PID6;
  volatile const uint32_t PID7;
  volatile const uint32_t PID0;
  volatile const uint32_t PID1;
  volatile const uint32_t PID2;
  volatile const uint32_t PID3;
  volatile const uint32_t CID0;
  volatile const uint32_t CID1;
  volatile const uint32_t CID2;
  volatile const uint32_t CID3;
} ITM_Type;
# 846 "./Source/CMSIS_core\\core_cm3.h" 3
typedef struct
{
  volatile uint32_t CTRL;
  volatile uint32_t CYCCNT;
  volatile uint32_t CPICNT;
  volatile uint32_t EXCCNT;
  volatile uint32_t SLEEPCNT;
  volatile uint32_t LSUCNT;
  volatile uint32_t FOLDCNT;
  volatile const uint32_t PCSR;
  volatile uint32_t COMP0;
  volatile uint32_t MASK0;
  volatile uint32_t FUNCTION0;
        uint32_t RESERVED0[1U];
  volatile uint32_t COMP1;
  volatile uint32_t MASK1;
  volatile uint32_t FUNCTION1;
        uint32_t RESERVED1[1U];
  volatile uint32_t COMP2;
  volatile uint32_t MASK2;
  volatile uint32_t FUNCTION2;
        uint32_t RESERVED2[1U];
  volatile uint32_t COMP3;
  volatile uint32_t MASK3;
  volatile uint32_t FUNCTION3;
} DWT_Type;
# 993 "./Source/CMSIS_core\\core_cm3.h" 3
typedef struct
{
  volatile const uint32_t SSPSR;
  volatile uint32_t CSPSR;
        uint32_t RESERVED0[2U];
  volatile uint32_t ACPR;
        uint32_t RESERVED1[55U];
  volatile uint32_t SPPR;
        uint32_t RESERVED2[131U];
  volatile const uint32_t FFSR;
  volatile uint32_t FFCR;
  volatile const uint32_t FSCR;
        uint32_t RESERVED3[759U];
  volatile const uint32_t TRIGGER;
  volatile const uint32_t FIFO0;
  volatile const uint32_t ITATBCTR2;
        uint32_t RESERVED4[1U];
  volatile const uint32_t ITATBCTR0;
  volatile const uint32_t FIFO1;
  volatile uint32_t ITCTRL;
        uint32_t RESERVED5[39U];
  volatile uint32_t CLAIMSET;
  volatile uint32_t CLAIMCLR;
        uint32_t RESERVED7[8U];
  volatile const uint32_t DEVID;
  volatile const uint32_t DEVTYPE;
} TPI_Type;
# 1155 "./Source/CMSIS_core\\core_cm3.h" 3
typedef struct
{
  volatile const uint32_t TYPE;
  volatile uint32_t CTRL;
  volatile uint32_t RNR;
  volatile uint32_t RBAR;
  volatile uint32_t RASR;
  volatile uint32_t RBAR_A1;
  volatile uint32_t RASR_A1;
  volatile uint32_t RBAR_A2;
  volatile uint32_t RASR_A2;
  volatile uint32_t RBAR_A3;
  volatile uint32_t RASR_A3;
} MPU_Type;
# 1251 "./Source/CMSIS_core\\core_cm3.h" 3
typedef struct
{
  volatile uint32_t DHCSR;
  volatile uint32_t DCRSR;
  volatile uint32_t DCRDR;
  volatile uint32_t DEMCR;
} CoreDebug_Type;
# 1477 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline void __NVIC_SetPriorityGrouping(uint32_t PriorityGroup)
{
  uint32_t reg_value;
  uint32_t PriorityGroupTmp = (PriorityGroup & (uint32_t)0x07UL);

  reg_value = ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->AIRCR;
  reg_value &= ~((uint32_t)((0xFFFFUL << 16U) | (7UL << 8U)));
  reg_value = (reg_value |
                ((uint32_t)0x5FAUL << 16U) |
                (PriorityGroupTmp << 8U) );
  ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->AIRCR = reg_value;
}







static __inline uint32_t __NVIC_GetPriorityGrouping(void)
{
  return ((uint32_t)((((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->AIRCR & (7UL << 8U)) >> 8U));
}
# 1508 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline void __NVIC_EnableIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    __asm volatile("":::"memory");
    ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ISER[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1UL << (((uint32_t)IRQn) & 0x1FUL));
    __asm volatile("":::"memory");
  }
}
# 1527 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline uint32_t __NVIC_GetEnableIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    return((uint32_t)(((((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ISER[(((uint32_t)IRQn) >> 5UL)] & (1UL << (((uint32_t)IRQn) & 0x1FUL))) != 0UL) ? 1UL : 0UL));
  }
  else
  {
    return(0U);
  }
}
# 1546 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline void __NVIC_DisableIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ICER[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1UL << (((uint32_t)IRQn) & 0x1FUL));
    __builtin_arm_dsb(0xF);
    __builtin_arm_isb(0xF);
  }
}
# 1565 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline uint32_t __NVIC_GetPendingIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    return((uint32_t)(((((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ISPR[(((uint32_t)IRQn) >> 5UL)] & (1UL << (((uint32_t)IRQn) & 0x1FUL))) != 0UL) ? 1UL : 0UL));
  }
  else
  {
    return(0U);
  }
}
# 1584 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline void __NVIC_SetPendingIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ISPR[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1UL << (((uint32_t)IRQn) & 0x1FUL));
  }
}
# 1599 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline void __NVIC_ClearPendingIRQ(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->ICPR[(((uint32_t)IRQn) >> 5UL)] = (uint32_t)(1UL << (((uint32_t)IRQn) & 0x1FUL));
  }
}
# 1616 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline uint32_t __NVIC_GetActive(IRQn_Type IRQn)
{
  if ((int32_t)(IRQn) >= 0)
  {
    return((uint32_t)(((((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->IABR[(((uint32_t)IRQn) >> 5UL)] & (1UL << (((uint32_t)IRQn) & 0x1FUL))) != 0UL) ? 1UL : 0UL));
  }
  else
  {
    return(0U);
  }
}
# 1638 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline void __NVIC_SetPriority(IRQn_Type IRQn, uint32_t priority)
{
  if ((int32_t)(IRQn) >= 0)
  {
    ((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->IP[((uint32_t)IRQn)] = (uint8_t)((priority << (8U - 5)) & (uint32_t)0xFFUL);
  }
  else
  {
    ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->SHP[(((uint32_t)IRQn) & 0xFUL)-4UL] = (uint8_t)((priority << (8U - 5)) & (uint32_t)0xFFUL);
  }
}
# 1660 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline uint32_t __NVIC_GetPriority(IRQn_Type IRQn)
{

  if ((int32_t)(IRQn) >= 0)
  {
    return(((uint32_t)((NVIC_Type *) ((0xE000E000UL) + 0x0100UL) )->IP[((uint32_t)IRQn)] >> (8U - 5)));
  }
  else
  {
    return(((uint32_t)((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->SHP[(((uint32_t)IRQn) & 0xFUL)-4UL] >> (8U - 5)));
  }
}
# 1685 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline uint32_t NVIC_EncodePriority (uint32_t PriorityGroup, uint32_t PreemptPriority, uint32_t SubPriority)
{
  uint32_t PriorityGroupTmp = (PriorityGroup & (uint32_t)0x07UL);
  uint32_t PreemptPriorityBits;
  uint32_t SubPriorityBits;

  PreemptPriorityBits = ((7UL - PriorityGroupTmp) > (uint32_t)(5)) ? (uint32_t)(5) : (uint32_t)(7UL - PriorityGroupTmp);
  SubPriorityBits = ((PriorityGroupTmp + (uint32_t)(5)) < (uint32_t)7UL) ? (uint32_t)0UL : (uint32_t)((PriorityGroupTmp - 7UL) + (uint32_t)(5));

  return (
           ((PreemptPriority & (uint32_t)((1UL << (PreemptPriorityBits)) - 1UL)) << SubPriorityBits) |
           ((SubPriority & (uint32_t)((1UL << (SubPriorityBits )) - 1UL)))
         );
}
# 1712 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline void NVIC_DecodePriority (uint32_t Priority, uint32_t PriorityGroup, uint32_t* const pPreemptPriority, uint32_t* const pSubPriority)
{
  uint32_t PriorityGroupTmp = (PriorityGroup & (uint32_t)0x07UL);
  uint32_t PreemptPriorityBits;
  uint32_t SubPriorityBits;

  PreemptPriorityBits = ((7UL - PriorityGroupTmp) > (uint32_t)(5)) ? (uint32_t)(5) : (uint32_t)(7UL - PriorityGroupTmp);
  SubPriorityBits = ((PriorityGroupTmp + (uint32_t)(5)) < (uint32_t)7UL) ? (uint32_t)0UL : (uint32_t)((PriorityGroupTmp - 7UL) + (uint32_t)(5));

  *pPreemptPriority = (Priority >> SubPriorityBits) & (uint32_t)((1UL << (PreemptPriorityBits)) - 1UL);
  *pSubPriority = (Priority ) & (uint32_t)((1UL << (SubPriorityBits )) - 1UL);
}
# 1735 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline void __NVIC_SetVector(IRQn_Type IRQn, uint32_t vector)
{
  uint32_t *vectors = (uint32_t *)((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->VTOR;
  vectors[(int32_t)IRQn + 16] = vector;

}
# 1751 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline uint32_t __NVIC_GetVector(IRQn_Type IRQn)
{
  uint32_t *vectors = (uint32_t *)((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->VTOR;
  return vectors[(int32_t)IRQn + 16];
}






__attribute__((__noreturn__)) static __inline void __NVIC_SystemReset(void)
{
  __builtin_arm_dsb(0xF);

  ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->AIRCR = (uint32_t)((0x5FAUL << 16U) |
                           (((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->AIRCR & (7UL << 8U)) |
                            (1UL << 2U) );
  __builtin_arm_dsb(0xF);

  for(;;)
  {
    __builtin_arm_nop();
  }
}
# 1784 "./Source/CMSIS_core\\core_cm3.h" 3
# 1 "./Source/CMSIS_core\\mpu_armv7.h" 1 3
# 29 "./Source/CMSIS_core\\mpu_armv7.h" 3
# 183 "./Source/CMSIS_core\\mpu_armv7.h" 3
typedef struct {
  uint32_t RBAR; //!< The region base address register value (RBAR)
  uint32_t RASR; //!< The region attribute and size register value (RASR) \ref MPU_RASR
} ARM_MPU_Region_t;




static __inline void ARM_MPU_Enable(uint32_t MPU_Control)
{
  __builtin_arm_dmb(0xF);
  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->CTRL = MPU_Control | (1UL );

  ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->SHCSR |= (1UL << 16U);

  __builtin_arm_dsb(0xF);
  __builtin_arm_isb(0xF);
}



static __inline void ARM_MPU_Disable(void)
{
  __builtin_arm_dmb(0xF);

  ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->SHCSR &= ~(1UL << 16U);

  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->CTRL &= ~(1UL );
  __builtin_arm_dsb(0xF);
  __builtin_arm_isb(0xF);
}




static __inline void ARM_MPU_ClrRegion(uint32_t rnr)
{
  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->RNR = rnr;
  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->RASR = 0U;
}





static __inline void ARM_MPU_SetRegion(uint32_t rbar, uint32_t rasr)
{
  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->RBAR = rbar;
  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->RASR = rasr;
}






static __inline void ARM_MPU_SetRegionEx(uint32_t rnr, uint32_t rbar, uint32_t rasr)
{
  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->RNR = rnr;
  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->RBAR = rbar;
  ((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->RASR = rasr;
}






static __inline void ARM_MPU_OrderedMemcpy(volatile uint32_t* dst, const uint32_t* __restrict src, uint32_t len)
{
  uint32_t i;
  for (i = 0U; i < len; ++i)
  {
    dst[i] = src[i];
  }
}





static __inline void ARM_MPU_Load(ARM_MPU_Region_t const* table, uint32_t cnt)
{
  const uint32_t rowWordSize = sizeof(ARM_MPU_Region_t)/4U;
  while (cnt > 4U) {
    ARM_MPU_OrderedMemcpy(&(((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->RBAR), &(table->RBAR), 4U*rowWordSize);
    table += 4U;
    cnt -= 4U;
  }
  ARM_MPU_OrderedMemcpy(&(((MPU_Type *) ((0xE000E000UL) + 0x0D90UL) )->RBAR), &(table->RBAR), cnt*rowWordSize);
}
# 1785 "./Source/CMSIS_core\\core_cm3.h" 2 3
# 1805 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline uint32_t SCB_GetFPUType(void)
{
    return 0U;
}
# 1836 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline uint32_t SysTick_Config(uint32_t ticks)
{
  if ((ticks - 1UL) > (0xFFFFFFUL ))
  {
    return (1UL);
  }

  ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->LOAD = (uint32_t)(ticks - 1UL);
  __NVIC_SetPriority (SysTick_IRQn, (1UL << 5) - 1UL);
  ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->VAL = 0UL;
  ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL = (1UL << 2U) |
                   (1UL << 1U) |
                   (1UL );
  return (0UL);
}
# 1866 "./Source/CMSIS_core\\core_cm3.h" 3
extern volatile int32_t ITM_RxBuffer;
# 1878 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline uint32_t ITM_SendChar (uint32_t ch)
{
  if (((((ITM_Type *) (0xE0000000UL) )->TCR & (1UL )) != 0UL) &&
      ((((ITM_Type *) (0xE0000000UL) )->TER & 1UL ) != 0UL) )
  {
    while (((ITM_Type *) (0xE0000000UL) )->PORT[0U].u32 == 0UL)
    {
      __builtin_arm_nop();
    }
    ((ITM_Type *) (0xE0000000UL) )->PORT[0U].u8 = (uint8_t)ch;
  }
  return (ch);
}
# 1899 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline int32_t ITM_ReceiveChar (void)
{
  int32_t ch = -1;

  if (ITM_RxBuffer != ((int32_t)0x5AA55AA5U))
  {
    ch = ITM_RxBuffer;
    ITM_RxBuffer = ((int32_t)0x5AA55AA5U);
  }

  return (ch);
}
# 1919 "./Source/CMSIS_core\\core_cm3.h" 3
static __inline int32_t ITM_CheckChar (void)
{

  if (ITM_RxBuffer == ((int32_t)0x5AA55AA5U))
  {
    return (0);
  }
  else
  {
    return (1);
  }
}
# 107 "C:/Users/marwa/AppData/Local/Arm/Packs/Keil/LPC1700_DFP/2.7.2/Device/Include\\LPC17xx.h" 2
# 1 "C:/Users/marwa/AppData/Local/Arm/Packs/Keil/LPC1700_DFP/2.7.2/Device/Include\\system_LPC17xx.h" 1
# 49 "C:/Users/marwa/AppData/Local/Arm/Packs/Keil/LPC1700_DFP/2.7.2/Device/Include\\system_LPC17xx.h"
extern uint32_t SystemCoreClock;






extern void SystemInit (void);







extern void SystemCoreClockUpdate (void);
# 108 "C:/Users/marwa/AppData/Local/Arm/Packs/Keil/LPC1700_DFP/2.7.2/Device/Include\\LPC17xx.h" 2
# 120 "C:/Users/marwa/AppData/Local/Arm/Packs/Keil/LPC1700_DFP/2.7.2/Device/Include\\LPC17xx.h"
typedef struct
{
  volatile uint32_t FLASHCFG;
       uint32_t RESERVED0[31];
  volatile uint32_t PLL0CON;
  volatile uint32_t PLL0CFG;
  volatile const uint32_t PLL0STAT;
  volatile uint32_t PLL0FEED;
       uint32_t RESERVED1[4];
  volatile uint32_t PLL1CON;
  volatile uint32_t PLL1CFG;
  volatile const uint32_t PLL1STAT;
  volatile uint32_t PLL1FEED;
       uint32_t RESERVED2[4];
  volatile uint32_t PCON;
  volatile uint32_t PCONP;
       uint32_t RESERVED3[15];
  volatile uint32_t CCLKCFG;
  volatile uint32_t USBCLKCFG;
  volatile uint32_t CLKSRCSEL;
  volatile uint32_t CANSLEEPCLR;
  volatile uint32_t CANWAKEFLAGS;
       uint32_t RESERVED4[10];
  volatile uint32_t EXTINT;
       uint32_t RESERVED5;
  volatile uint32_t EXTMODE;
  volatile uint32_t EXTPOLAR;
       uint32_t RESERVED6[12];
  volatile uint32_t RSID;
       uint32_t RESERVED7[7];
  volatile uint32_t SCS;
  volatile uint32_t IRCTRIM;
  volatile uint32_t PCLKSEL0;
  volatile uint32_t PCLKSEL1;
       uint32_t RESERVED8[4];
  volatile uint32_t USBIntSt;
  volatile uint32_t DMAREQSEL;
  volatile uint32_t CLKOUTCFG;
 } LPC_SC_TypeDef;



typedef struct
{
  volatile uint32_t PINSEL0;
  volatile uint32_t PINSEL1;
  volatile uint32_t PINSEL2;
  volatile uint32_t PINSEL3;
  volatile uint32_t PINSEL4;
  volatile uint32_t PINSEL5;
  volatile uint32_t PINSEL6;
  volatile uint32_t PINSEL7;
  volatile uint32_t PINSEL8;
  volatile uint32_t PINSEL9;
  volatile uint32_t PINSEL10;
       uint32_t RESERVED0[5];
  volatile uint32_t PINMODE0;
  volatile uint32_t PINMODE1;
  volatile uint32_t PINMODE2;
  volatile uint32_t PINMODE3;
  volatile uint32_t PINMODE4;
  volatile uint32_t PINMODE5;
  volatile uint32_t PINMODE6;
  volatile uint32_t PINMODE7;
  volatile uint32_t PINMODE8;
  volatile uint32_t PINMODE9;
  volatile uint32_t PINMODE_OD0;
  volatile uint32_t PINMODE_OD1;
  volatile uint32_t PINMODE_OD2;
  volatile uint32_t PINMODE_OD3;
  volatile uint32_t PINMODE_OD4;
  volatile uint32_t I2CPADCFG;
} LPC_PINCON_TypeDef;



typedef struct
{
  union {
    volatile uint32_t FIODIR;
    struct {
      volatile uint16_t FIODIRL;
      volatile uint16_t FIODIRH;
    };
    struct {
      volatile uint8_t FIODIR0;
      volatile uint8_t FIODIR1;
      volatile uint8_t FIODIR2;
      volatile uint8_t FIODIR3;
    };
  };
  uint32_t RESERVED0[3];
  union {
    volatile uint32_t FIOMASK;
    struct {
      volatile uint16_t FIOMASKL;
      volatile uint16_t FIOMASKH;
    };
    struct {
      volatile uint8_t FIOMASK0;
      volatile uint8_t FIOMASK1;
      volatile uint8_t FIOMASK2;
      volatile uint8_t FIOMASK3;
    };
  };
  union {
    volatile uint32_t FIOPIN;
    struct {
      volatile uint16_t FIOPINL;
      volatile uint16_t FIOPINH;
    };
    struct {
      volatile uint8_t FIOPIN0;
      volatile uint8_t FIOPIN1;
      volatile uint8_t FIOPIN2;
      volatile uint8_t FIOPIN3;
    };
  };
  union {
    volatile uint32_t FIOSET;
    struct {
      volatile uint16_t FIOSETL;
      volatile uint16_t FIOSETH;
    };
    struct {
      volatile uint8_t FIOSET0;
      volatile uint8_t FIOSET1;
      volatile uint8_t FIOSET2;
      volatile uint8_t FIOSET3;
    };
  };
  union {
    volatile uint32_t FIOCLR;
    struct {
      volatile uint16_t FIOCLRL;
      volatile uint16_t FIOCLRH;
    };
    struct {
      volatile uint8_t FIOCLR0;
      volatile uint8_t FIOCLR1;
      volatile uint8_t FIOCLR2;
      volatile uint8_t FIOCLR3;
    };
  };
} LPC_GPIO_TypeDef;


typedef struct
{
  volatile const uint32_t IntStatus;
  volatile const uint32_t IO0IntStatR;
  volatile const uint32_t IO0IntStatF;
  volatile uint32_t IO0IntClr;
  volatile uint32_t IO0IntEnR;
  volatile uint32_t IO0IntEnF;
       uint32_t RESERVED0[3];
  volatile const uint32_t IO2IntStatR;
  volatile const uint32_t IO2IntStatF;
  volatile uint32_t IO2IntClr;
  volatile uint32_t IO2IntEnR;
  volatile uint32_t IO2IntEnF;
} LPC_GPIOINT_TypeDef;



typedef struct
{
  volatile uint32_t IR;
  volatile uint32_t TCR;
  volatile uint32_t TC;
  volatile uint32_t PR;
  volatile uint32_t PC;
  volatile uint32_t MCR;
  volatile uint32_t MR0;
  volatile uint32_t MR1;
  volatile uint32_t MR2;
  volatile uint32_t MR3;
  volatile uint32_t CCR;
  volatile const uint32_t CR0;
  volatile const uint32_t CR1;
       uint32_t RESERVED0[2];
  volatile uint32_t EMR;
       uint32_t RESERVED1[12];
  volatile uint32_t CTCR;
} LPC_TIM_TypeDef;



typedef struct
{
  volatile uint32_t IR;
  volatile uint32_t TCR;
  volatile uint32_t TC;
  volatile uint32_t PR;
  volatile uint32_t PC;
  volatile uint32_t MCR;
  volatile uint32_t MR0;
  volatile uint32_t MR1;
  volatile uint32_t MR2;
  volatile uint32_t MR3;
  volatile uint32_t CCR;
  volatile const uint32_t CR0;
  volatile const uint32_t CR1;
  volatile const uint32_t CR2;
  volatile const uint32_t CR3;
       uint32_t RESERVED0;
  volatile uint32_t MR4;
  volatile uint32_t MR5;
  volatile uint32_t MR6;
  volatile uint32_t PCR;
  volatile uint32_t LER;
       uint32_t RESERVED1[7];
  volatile uint32_t CTCR;
} LPC_PWM_TypeDef;



typedef struct
{
  union {
  volatile const uint8_t RBR;
  volatile uint8_t THR;
  volatile uint8_t DLL;
       uint32_t RESERVED0;
  };
  union {
  volatile uint8_t DLM;
  volatile uint32_t IER;
  };
  union {
  volatile const uint32_t IIR;
  volatile uint8_t FCR;
  };
  volatile uint8_t LCR;
       uint8_t RESERVED1[7];
  volatile const uint8_t LSR;
       uint8_t RESERVED2[7];
  volatile uint8_t SCR;
       uint8_t RESERVED3[3];
  volatile uint32_t ACR;
  volatile uint8_t ICR;
       uint8_t RESERVED4[3];
  volatile uint8_t FDR;
       uint8_t RESERVED5[7];
  volatile uint8_t TER;
       uint8_t RESERVED6[3];
} LPC_UART_TypeDef;


typedef struct
{
  union {
  volatile const uint8_t RBR;
  volatile uint8_t THR;
  volatile uint8_t DLL;
       uint32_t RESERVED0;
  };
  union {
  volatile uint8_t DLM;
       uint8_t RESERVED1[3];
  volatile uint32_t IER;
  };
  union {
  volatile const uint32_t IIR;
  volatile uint8_t FCR;
  };
  volatile uint8_t LCR;
       uint8_t RESERVED2[3];
  volatile uint8_t MCR;
       uint8_t RESERVED3[3];
  volatile const uint8_t LSR;
       uint8_t RESERVED4[3];
  volatile const uint8_t MSR;
       uint8_t RESERVED5[3];
  volatile uint8_t SCR;
       uint8_t RESERVED6[3];
  volatile uint32_t ACR;
       uint32_t RESERVED7;
  volatile uint32_t FDR;
       uint32_t RESERVED8;
  volatile uint8_t TER;
       uint8_t RESERVED9[27];
  volatile uint8_t RS485CTRL;
       uint8_t RESERVED10[3];
  volatile uint8_t ADRMATCH;
       uint8_t RESERVED11[3];
  volatile uint8_t RS485DLY;
       uint8_t RESERVED12[3];
} LPC_UART1_TypeDef;



typedef struct
{
  volatile uint32_t SPCR;
  volatile const uint32_t SPSR;
  volatile uint32_t SPDR;
  volatile uint32_t SPCCR;
       uint32_t RESERVED0[3];
  volatile uint32_t SPINT;
} LPC_SPI_TypeDef;



typedef struct
{
  volatile uint32_t CR0;
  volatile uint32_t CR1;
  volatile uint32_t DR;
  volatile const uint32_t SR;
  volatile uint32_t CPSR;
  volatile uint32_t IMSC;
  volatile uint32_t RIS;
  volatile uint32_t MIS;
  volatile uint32_t ICR;
  volatile uint32_t DMACR;
} LPC_SSP_TypeDef;



typedef struct
{
  volatile uint32_t I2CONSET;
  volatile const uint32_t I2STAT;
  volatile uint32_t I2DAT;
  volatile uint32_t I2ADR0;
  volatile uint32_t I2SCLH;
  volatile uint32_t I2SCLL;
  volatile uint32_t I2CONCLR;
  volatile uint32_t MMCTRL;
  volatile uint32_t I2ADR1;
  volatile uint32_t I2ADR2;
  volatile uint32_t I2ADR3;
  volatile const uint32_t I2DATA_BUFFER;
  volatile uint32_t I2MASK0;
  volatile uint32_t I2MASK1;
  volatile uint32_t I2MASK2;
  volatile uint32_t I2MASK3;
} LPC_I2C_TypeDef;



typedef struct
{
  volatile uint32_t I2SDAO;
  volatile uint32_t I2SDAI;
  volatile uint32_t I2STXFIFO;
  volatile const uint32_t I2SRXFIFO;
  volatile const uint32_t I2SSTATE;
  volatile uint32_t I2SDMA1;
  volatile uint32_t I2SDMA2;
  volatile uint32_t I2SIRQ;
  volatile uint32_t I2STXRATE;
  volatile uint32_t I2SRXRATE;
  volatile uint32_t I2STXBITRATE;
  volatile uint32_t I2SRXBITRATE;
  volatile uint32_t I2STXMODE;
  volatile uint32_t I2SRXMODE;
} LPC_I2S_TypeDef;



typedef struct
{
  volatile uint32_t RICOMPVAL;
  volatile uint32_t RIMASK;
  volatile uint8_t RICTRL;
       uint8_t RESERVED0[3];
  volatile uint32_t RICOUNTER;
} LPC_RIT_TypeDef;



typedef struct
{
  volatile uint8_t ILR;
       uint8_t RESERVED0[7];
  volatile uint8_t CCR;
       uint8_t RESERVED1[3];
  volatile uint8_t CIIR;
       uint8_t RESERVED2[3];
  volatile uint8_t AMR;
       uint8_t RESERVED3[3];
  volatile const uint32_t CTIME0;
  volatile const uint32_t CTIME1;
  volatile const uint32_t CTIME2;
  volatile uint8_t SEC;
       uint8_t RESERVED4[3];
  volatile uint8_t MIN;
       uint8_t RESERVED5[3];
  volatile uint8_t HOUR;
       uint8_t RESERVED6[3];
  volatile uint8_t DOM;
       uint8_t RESERVED7[3];
  volatile uint8_t DOW;
       uint8_t RESERVED8[3];
  volatile uint16_t DOY;
       uint16_t RESERVED9;
  volatile uint8_t MONTH;
       uint8_t RESERVED10[3];
  volatile uint16_t YEAR;
       uint16_t RESERVED11;
  volatile uint32_t CALIBRATION;
  volatile uint32_t GPREG0;
  volatile uint32_t GPREG1;
  volatile uint32_t GPREG2;
  volatile uint32_t GPREG3;
  volatile uint32_t GPREG4;
  volatile uint8_t RTC_AUXEN;
       uint8_t RESERVED12[3];
  volatile uint8_t RTC_AUX;
       uint8_t RESERVED13[3];
  volatile uint8_t ALSEC;
       uint8_t RESERVED14[3];
  volatile uint8_t ALMIN;
       uint8_t RESERVED15[3];
  volatile uint8_t ALHOUR;
       uint8_t RESERVED16[3];
  volatile uint8_t ALDOM;
       uint8_t RESERVED17[3];
  volatile uint8_t ALDOW;
       uint8_t RESERVED18[3];
  volatile uint16_t ALDOY;
       uint16_t RESERVED19;
  volatile uint8_t ALMON;
       uint8_t RESERVED20[3];
  volatile uint16_t ALYEAR;
       uint16_t RESERVED21;
} LPC_RTC_TypeDef;



typedef struct
{
  volatile uint8_t WDMOD;
       uint8_t RESERVED0[3];
  volatile uint32_t WDTC;
  volatile uint8_t WDFEED;
       uint8_t RESERVED1[3];
  volatile const uint32_t WDTV;
  volatile uint32_t WDCLKSEL;
} LPC_WDT_TypeDef;



typedef struct
{
  volatile uint32_t ADCR;
  volatile uint32_t ADGDR;
       uint32_t RESERVED0;
  volatile uint32_t ADINTEN;
  volatile const uint32_t ADDR0;
  volatile const uint32_t ADDR1;
  volatile const uint32_t ADDR2;
  volatile const uint32_t ADDR3;
  volatile const uint32_t ADDR4;
  volatile const uint32_t ADDR5;
  volatile const uint32_t ADDR6;
  volatile const uint32_t ADDR7;
  volatile const uint32_t ADSTAT;
  volatile uint32_t ADTRM;
} LPC_ADC_TypeDef;



typedef struct
{
  volatile uint32_t DACR;
  volatile uint32_t DACCTRL;
  volatile uint16_t DACCNTVAL;
       uint16_t RESERVED;
} LPC_DAC_TypeDef;



typedef struct
{
  volatile const uint32_t MCCON;
  volatile uint32_t MCCON_SET;
  volatile uint32_t MCCON_CLR;
  volatile const uint32_t MCCAPCON;
  volatile uint32_t MCCAPCON_SET;
  volatile uint32_t MCCAPCON_CLR;
  volatile uint32_t MCTIM0;
  volatile uint32_t MCTIM1;
  volatile uint32_t MCTIM2;
  volatile uint32_t MCPER0;
  volatile uint32_t MCPER1;
  volatile uint32_t MCPER2;
  volatile uint32_t MCPW0;
  volatile uint32_t MCPW1;
  volatile uint32_t MCPW2;
  volatile uint32_t MCDEADTIME;
  volatile uint32_t MCCCP;
  volatile uint32_t MCCR0;
  volatile uint32_t MCCR1;
  volatile uint32_t MCCR2;
  volatile const uint32_t MCINTEN;
  volatile uint32_t MCINTEN_SET;
  volatile uint32_t MCINTEN_CLR;
  volatile const uint32_t MCCNTCON;
  volatile uint32_t MCCNTCON_SET;
  volatile uint32_t MCCNTCON_CLR;
  volatile const uint32_t MCINTFLAG;
  volatile uint32_t MCINTFLAG_SET;
  volatile uint32_t MCINTFLAG_CLR;
  volatile uint32_t MCCAP_CLR;
} LPC_MCPWM_TypeDef;



typedef struct
{
  volatile uint32_t QEICON;
  volatile const uint32_t QEISTAT;
  volatile uint32_t QEICONF;
  volatile const uint32_t QEIPOS;
  volatile uint32_t QEIMAXPOS;
  volatile uint32_t CMPOS0;
  volatile uint32_t CMPOS1;
  volatile uint32_t CMPOS2;
  volatile const uint32_t INXCNT;
  volatile uint32_t INXCMP;
  volatile uint32_t QEILOAD;
  volatile const uint32_t QEITIME;
  volatile const uint32_t QEIVEL;
  volatile const uint32_t QEICAP;
  volatile uint32_t VELCOMP;
  volatile uint32_t FILTER;
       uint32_t RESERVED0[998];
  volatile uint32_t QEIIEC;
  volatile uint32_t QEIIES;
  volatile const uint32_t QEIINTSTAT;
  volatile const uint32_t QEIIE;
  volatile uint32_t QEICLR;
  volatile uint32_t QEISET;
} LPC_QEI_TypeDef;



typedef struct
{
  volatile uint32_t mask[512];
} LPC_CANAF_RAM_TypeDef;


typedef struct
{
  volatile uint32_t AFMR;
  volatile uint32_t SFF_sa;
  volatile uint32_t SFF_GRP_sa;
  volatile uint32_t EFF_sa;
  volatile uint32_t EFF_GRP_sa;
  volatile uint32_t ENDofTable;
  volatile const uint32_t LUTerrAd;
  volatile const uint32_t LUTerr;
  volatile uint32_t FCANIE;
  volatile uint32_t FCANIC0;
  volatile uint32_t FCANIC1;
} LPC_CANAF_TypeDef;


typedef struct
{
  volatile const uint32_t CANTxSR;
  volatile const uint32_t CANRxSR;
  volatile const uint32_t CANMSR;
} LPC_CANCR_TypeDef;


typedef struct
{
  volatile uint32_t MOD;
  volatile uint32_t CMR;
  volatile uint32_t GSR;
  volatile const uint32_t ICR;
  volatile uint32_t IER;
  volatile uint32_t BTR;
  volatile uint32_t EWL;
  volatile const uint32_t SR;
  volatile uint32_t RFS;
  volatile uint32_t RID;
  volatile uint32_t RDA;
  volatile uint32_t RDB;
  volatile uint32_t TFI1;
  volatile uint32_t TID1;
  volatile uint32_t TDA1;
  volatile uint32_t TDB1;
  volatile uint32_t TFI2;
  volatile uint32_t TID2;
  volatile uint32_t TDA2;
  volatile uint32_t TDB2;
  volatile uint32_t TFI3;
  volatile uint32_t TID3;
  volatile uint32_t TDA3;
  volatile uint32_t TDB3;
} LPC_CAN_TypeDef;



typedef struct
{
  volatile const uint32_t DMACIntStat;
  volatile const uint32_t DMACIntTCStat;
  volatile uint32_t DMACIntTCClear;
  volatile const uint32_t DMACIntErrStat;
  volatile uint32_t DMACIntErrClr;
  volatile const uint32_t DMACRawIntTCStat;
  volatile const uint32_t DMACRawIntErrStat;
  volatile const uint32_t DMACEnbldChns;
  volatile uint32_t DMACSoftBReq;
  volatile uint32_t DMACSoftSReq;
  volatile uint32_t DMACSoftLBReq;
  volatile uint32_t DMACSoftLSReq;
  volatile uint32_t DMACConfig;
  volatile uint32_t DMACSync;
} LPC_GPDMA_TypeDef;


typedef struct
{
  volatile uint32_t DMACCSrcAddr;
  volatile uint32_t DMACCDestAddr;
  volatile uint32_t DMACCLLI;
  volatile uint32_t DMACCControl;
  volatile uint32_t DMACCConfig;
} LPC_GPDMACH_TypeDef;



typedef struct
{
  volatile const uint32_t HcRevision;
  volatile uint32_t HcControl;
  volatile uint32_t HcCommandStatus;
  volatile uint32_t HcInterruptStatus;
  volatile uint32_t HcInterruptEnable;
  volatile uint32_t HcInterruptDisable;
  volatile uint32_t HcHCCA;
  volatile const uint32_t HcPeriodCurrentED;
  volatile uint32_t HcControlHeadED;
  volatile uint32_t HcControlCurrentED;
  volatile uint32_t HcBulkHeadED;
  volatile uint32_t HcBulkCurrentED;
  volatile const uint32_t HcDoneHead;
  volatile uint32_t HcFmInterval;
  volatile const uint32_t HcFmRemaining;
  volatile const uint32_t HcFmNumber;
  volatile uint32_t HcPeriodicStart;
  volatile uint32_t HcLSTreshold;
  volatile uint32_t HcRhDescriptorA;
  volatile uint32_t HcRhDescriptorB;
  volatile uint32_t HcRhStatus;
  volatile uint32_t HcRhPortStatus1;
  volatile uint32_t HcRhPortStatus2;
       uint32_t RESERVED0[40];
  volatile const uint32_t Module_ID;

  volatile const uint32_t OTGIntSt;
  volatile uint32_t OTGIntEn;
  volatile uint32_t OTGIntSet;
  volatile uint32_t OTGIntClr;
  volatile uint32_t OTGStCtrl;
  volatile uint32_t OTGTmr;
       uint32_t RESERVED1[58];

  volatile const uint32_t USBDevIntSt;
  volatile uint32_t USBDevIntEn;
  volatile uint32_t USBDevIntClr;
  volatile uint32_t USBDevIntSet;

  volatile uint32_t USBCmdCode;
  volatile const uint32_t USBCmdData;

  volatile const uint32_t USBRxData;
  volatile uint32_t USBTxData;
  volatile const uint32_t USBRxPLen;
  volatile uint32_t USBTxPLen;
  volatile uint32_t USBCtrl;
  volatile uint32_t USBDevIntPri;

  volatile const uint32_t USBEpIntSt;
  volatile uint32_t USBEpIntEn;
  volatile uint32_t USBEpIntClr;
  volatile uint32_t USBEpIntSet;
  volatile uint32_t USBEpIntPri;

  volatile uint32_t USBReEp;
  volatile uint32_t USBEpInd;
  volatile uint32_t USBMaxPSize;

  volatile const uint32_t USBDMARSt;
  volatile uint32_t USBDMARClr;
  volatile uint32_t USBDMARSet;
       uint32_t RESERVED2[9];
  volatile uint32_t USBUDCAH;
  volatile const uint32_t USBEpDMASt;
  volatile uint32_t USBEpDMAEn;
  volatile uint32_t USBEpDMADis;
  volatile const uint32_t USBDMAIntSt;
  volatile uint32_t USBDMAIntEn;
       uint32_t RESERVED3[2];
  volatile const uint32_t USBEoTIntSt;
  volatile uint32_t USBEoTIntClr;
  volatile uint32_t USBEoTIntSet;
  volatile const uint32_t USBNDDRIntSt;
  volatile uint32_t USBNDDRIntClr;
  volatile uint32_t USBNDDRIntSet;
  volatile const uint32_t USBSysErrIntSt;
  volatile uint32_t USBSysErrIntClr;
  volatile uint32_t USBSysErrIntSet;
       uint32_t RESERVED4[15];

  union {
  volatile const uint32_t I2C_RX;
  volatile uint32_t I2C_TX;
  };
  volatile const uint32_t I2C_STS;
  volatile uint32_t I2C_CTL;
  volatile uint32_t I2C_CLKHI;
  volatile uint32_t I2C_CLKLO;
       uint32_t RESERVED5[824];

  union {
  volatile uint32_t USBClkCtrl;
  volatile uint32_t OTGClkCtrl;
  };
  union {
  volatile const uint32_t USBClkSt;
  volatile const uint32_t OTGClkSt;
  };
} LPC_USB_TypeDef;



typedef struct
{
  volatile uint32_t MAC1;
  volatile uint32_t MAC2;
  volatile uint32_t IPGT;
  volatile uint32_t IPGR;
  volatile uint32_t CLRT;
  volatile uint32_t MAXF;
  volatile uint32_t SUPP;
  volatile uint32_t TEST;
  volatile uint32_t MCFG;
  volatile uint32_t MCMD;
  volatile uint32_t MADR;
  volatile uint32_t MWTD;
  volatile const uint32_t MRDD;
  volatile const uint32_t MIND;
       uint32_t RESERVED0[2];
  volatile uint32_t SA0;
  volatile uint32_t SA1;
  volatile uint32_t SA2;
       uint32_t RESERVED1[45];
  volatile uint32_t Command;
  volatile const uint32_t Status;
  volatile uint32_t RxDescriptor;
  volatile uint32_t RxStatus;
  volatile uint32_t RxDescriptorNumber;
  volatile const uint32_t RxProduceIndex;
  volatile uint32_t RxConsumeIndex;
  volatile uint32_t TxDescriptor;
  volatile uint32_t TxStatus;
  volatile uint32_t TxDescriptorNumber;
  volatile uint32_t TxProduceIndex;
  volatile const uint32_t TxConsumeIndex;
       uint32_t RESERVED2[10];
  volatile const uint32_t TSV0;
  volatile const uint32_t TSV1;
  volatile const uint32_t RSV;
       uint32_t RESERVED3[3];
  volatile uint32_t FlowControlCounter;
  volatile const uint32_t FlowControlStatus;
       uint32_t RESERVED4[34];
  volatile uint32_t RxFilterCtrl;
  volatile uint32_t RxFilterWoLStatus;
  volatile uint32_t RxFilterWoLClear;
       uint32_t RESERVED5;
  volatile uint32_t HashFilterL;
  volatile uint32_t HashFilterH;
       uint32_t RESERVED6[882];
  volatile const uint32_t IntStatus;
  volatile uint32_t IntEnable;
  volatile uint32_t IntClear;
  volatile uint32_t IntSet;
       uint32_t RESERVED7;
  volatile uint32_t PowerDown;
       uint32_t RESERVED8;
  volatile uint32_t Module_ID;
} LPC_EMAC_TypeDef;
# 6 "Source/platform\\exam_board.h" 2
# 1 "Source/platform\\exam_config.h" 1
# 7 "Source/platform\\exam_board.h" 2
# 17 "Source/platform\\exam_board.h"
typedef enum {
  BOARD_OK = 0,
  BOARD_INVALID = -1,
  BOARD_BUSY = -2,
  BOARD_RANGE = -3,
  BOARD_NOT_ENABLED = -4,
  BOARD_NOT_READY = -5
} board_status_t;



typedef enum { BOARD_BUTTON_INT0 = 0, BOARD_BUTTON_KEY1 = 1, BOARD_BUTTON_KEY2 = 2 } board_button_t;
typedef enum { BUTTON_EVENT_PRESS = 1, BUTTON_EVENT_RELEASE = 2 } button_event_t;
typedef void (*button_callback_t)(board_button_t button, button_event_t event);



enum {
  JOYSTICK_SELECT = 1u << 0,
  JOYSTICK_DOWN = 1u << 1,
  JOYSTICK_LEFT = 1u << 2,
  JOYSTICK_RIGHT = 1u << 3,
  JOYSTICK_UP = 1u << 4
};
typedef void (*joystick_callback_t)(uint32_t current_mask, uint32_t changed_mask);


enum { TIMER_ACTION_INTERRUPT = 1u, TIMER_ACTION_RESET = 2u, TIMER_ACTION_STOP = 4u };


typedef enum { CAPTURE_RISING = 1, CAPTURE_FALLING = 2, CAPTURE_BOTH = 3 } timer_capture_edge_t;


typedef enum { TIMER_MODE_TIMER = 0, TIMER_MODE_COUNTER_RISING = 1, TIMER_MODE_COUNTER_FALLING = 2, TIMER_MODE_COUNTER_BOTH = 3 } timer_counter_mode_t;


typedef enum { EXT_MATCH_DO_NOTHING = 0, EXT_MATCH_CLEAR = 1, EXT_MATCH_SET = 2, EXT_MATCH_TOGGLE = 3 } timer_external_match_t;
typedef void (*timer_callback_t)(uint8_t timer, uint32_t pending_flags);



typedef enum {
  ADC_TRIGGER_SOFTWARE = 0,
  ADC_TRIGGER_P2_10 = 2,
  ADC_TRIGGER_P2_11 = 3,
  ADC_TRIGGER_MAT0_1 = 4,
  ADC_TRIGGER_MAT0_3 = 5,
  ADC_TRIGGER_MAT1_0 = 6,
  ADC_TRIGGER_MAT1_1 = 7
} adc_trigger_t;

typedef struct {
  uint32_t raw;
  uint16_t value;
  uint8_t channel;
  uint8_t done;
  uint8_t overrun;
} adc_sample_t;



typedef struct {
  uint32_t exception_number;
  uint32_t exc_return;
  uint32_t r0, r1, r2, r3, r12, lr, pc, xpsr;
  uint32_t cfsr, hfsr, bfar, mmfar;
} fault_snapshot_t;


typedef struct { uint32_t r0, r1, r2, r3, r12, lr, pc, xpsr; } svc_context_t;
# 99 "Source/platform\\exam_board.h"
board_status_t timer_every_ms(int timer, int milliseconds, timer_callback_t callback);
board_status_t timer_every_hz(int timer, int hertz, timer_callback_t callback);
board_status_t systick_every_ms(int milliseconds);

board_status_t potentiometer_start(void);
board_status_t potentiometer_read(int *value);
board_status_t speaker_write(int value);
board_status_t speaker_write_percent(int percent);

int int0_pressed(void);
int key1_pressed(void);
int key2_pressed(void);
int joystick_up_pressed(void);
int joystick_down_pressed(void);
int joystick_left_pressed(void);
int joystick_right_pressed(void);
int joystick_button_pressed(void);


enum {
  SELF_TEST_LED_API = 1u << 0,
  SELF_TEST_JOYSTICK_IDLE = 1u << 1,
  SELF_TEST_ADC_CLOCK = 1u << 2,
  SELF_TEST_SYSTICK_RANGE = 1u << 3,
  SELF_TEST_DAC_RANGE = 1u << 4
};


void board_init(void);


void board_idle(void);




board_status_t led_write_number(uint8_t led_number, uint8_t on);

board_status_t led_on(uint8_t led_number);
board_status_t led_off(uint8_t led_number);
void led_all_off(void);
board_status_t led_write_mask(uint8_t mask);
board_status_t led_toggle(uint8_t led_number);
uint8_t led_read_mask(void);
void led_write8(uint8_t value);




void buttons_init(button_callback_t callback);
void buttons_set_confirmation_ms(uint32_t milliseconds);
uint32_t buttons_pressed_mask(void);

uint8_t button_is_pressed(board_button_t button);
void joystick_init(joystick_callback_t callback);
uint32_t joystick_read(void);

uint8_t joystick_is_pressed(uint32_t direction);
uint32_t joystick_first_movement(void);
void joystick_reset_first_movement(void);
# 172 "Source/platform\\exam_board.h"
board_status_t timer_set_clock_divider(uint8_t timer, uint8_t divider);
uint32_t timer_peripheral_clock_hz(uint8_t timer);
board_status_t timer_set_prescaler(uint8_t timer, uint32_t prescaler);
uint32_t timer_counter_clock_hz(uint8_t timer);
board_status_t timer_calculate_match_for_frequency(uint8_t timer, uint32_t frequency_hz,
                                                   uint32_t events_per_cycle, uint32_t *match_value);
board_status_t timer_configure_frequency(uint8_t timer, uint8_t match, uint32_t frequency_hz,
                                         uint32_t events_per_cycle, uint32_t actions);
board_status_t timer_start_periodic_interrupt_hz(uint8_t timer, uint32_t frequency_hz,
                                                 uint32_t events_per_cycle,
                                                 timer_callback_t callback);

board_status_t timer_start_periodic_interrupt_ms(uint8_t timer, uint32_t period_ms,
                                                 timer_callback_t callback);
uint8_t timer_match_occurred(uint32_t pending_flags, uint8_t match);
uint8_t timer_capture_occurred(uint32_t pending_flags, uint8_t capture);
board_status_t timer_configure_match(uint8_t timer, uint8_t match, uint32_t value, uint32_t actions);
board_status_t timer_configure_capture(uint8_t timer, uint8_t capture, timer_capture_edge_t edge, uint8_t interrupt_enable);
board_status_t timer_read_capture(uint8_t timer, uint8_t capture, uint32_t *value);
board_status_t timer_set_counter_mode(uint8_t timer, timer_counter_mode_t mode, uint8_t capture_input);
board_status_t timer_configure_external_match(uint8_t timer, uint8_t match, timer_external_match_t action, uint8_t initial_state);
board_status_t timer_start(uint8_t timer);
board_status_t timer_stop(uint8_t timer);
board_status_t timer_reset(uint8_t timer);
board_status_t timer_set_callback(uint8_t timer, timer_callback_t callback);
uint32_t timer_read_counter(uint8_t timer);




board_status_t rit_scheduler_start(void);
void rit_scheduler_stop(void);
uint32_t rit_scheduler_ticks(void);
board_status_t rit_raw_configure(uint32_t compare, uint32_t mask, uint8_t clear_on_match);
board_status_t rit_raw_start(void);
void rit_raw_stop(void);
uint32_t rit_raw_read(void);




board_status_t systick_configure(uint32_t reload, uint8_t periodic, uint8_t interrupt_enable);

board_status_t systick_start_periodic_ms(uint32_t period_ms);
board_status_t systick_set_clock_source(uint8_t processor_clock);
uint32_t systick_calibration_value(void);
uint8_t systick_has_precise_calibration(void);
uint32_t systick_ticks(void);




board_status_t adc_init(uint8_t channel, uint32_t peripheral_clock_hz);
board_status_t adc_configure_trigger(adc_trigger_t trigger, uint8_t falling_edge);
board_status_t adc_start_conversion(void);
board_status_t adc_start_burst(uint32_t channel_mask);
void adc_stop_burst(void);
board_status_t adc_read_channel(uint8_t channel, adc_sample_t *sample);

board_status_t adc_read_value(uint8_t channel, uint16_t *value);
uint32_t adc_clock_hz(void);




board_status_t dac_init(void);
board_status_t dac_write(uint16_t value);
void dac_silence(void);
board_status_t dac_validate_update_rate(uint32_t update_hz);
board_status_t dac_play_samples(const uint16_t *samples, uint32_t count, uint32_t update_hz, uint8_t timer);




uint32_t critical_enter(void);
void critical_exit(uint32_t previous_primask);
void event_flags_set(uint32_t flags);
uint32_t event_flags_take(uint32_t mask);

extern volatile fault_snapshot_t fault_snapshot;
extern volatile uint8_t fault_snapshot_valid;


void fault_traps_configure(void);
void svc_dispatch(uint8_t service_number, svc_context_t *context);




void *board_direct_register(const char *name);
void exam_user_10ms_hook(void);
uint32_t board_self_test_run(void);
# 2 "Source/platform/exam_board.c" 2
# 1 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdarg.h" 1 3
# 40 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdarg.h" 3
  typedef __builtin_va_list va_list;
# 134 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\stdarg.h" 3
     typedef va_list __gnuc_va_list;
# 3 "Source/platform/exam_board.c" 2
# 1 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 1 3
# 51 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
    typedef unsigned int size_t;






extern __attribute__((__nothrow__)) void *memcpy(void * __restrict ,
                    const void * __restrict , size_t ) __attribute__((__nonnull__(1,2)));






extern __attribute__((__nothrow__)) void *memmove(void * ,
                    const void * , size_t ) __attribute__((__nonnull__(1,2)));
# 77 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strcpy(char * __restrict , const char * __restrict ) __attribute__((__nonnull__(1,2)));






extern __attribute__((__nothrow__)) char *strncpy(char * __restrict , const char * __restrict , size_t ) __attribute__((__nonnull__(1,2)));
# 93 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strcat(char * __restrict , const char * __restrict ) __attribute__((__nonnull__(1,2)));






extern __attribute__((__nothrow__)) char *strncat(char * __restrict , const char * __restrict , size_t ) __attribute__((__nonnull__(1,2)));
# 117 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) int memcmp(const void * , const void * , size_t ) __attribute__((__nonnull__(1,2)));







extern __attribute__((__nothrow__)) int strcmp(const char * , const char * ) __attribute__((__nonnull__(1,2)));






extern __attribute__((__nothrow__)) int strncmp(const char * , const char * , size_t ) __attribute__((__nonnull__(1,2)));
# 141 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) int strcasecmp(const char * , const char * ) __attribute__((__nonnull__(1,2)));







extern __attribute__((__nothrow__)) int strncasecmp(const char * , const char * , size_t ) __attribute__((__nonnull__(1,2)));
# 158 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) int strcoll(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 169 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) size_t strxfrm(char * __restrict , const char * __restrict , size_t ) __attribute__((__nonnull__(2)));
# 193 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) void *memchr(const void * , int , size_t ) __attribute__((__nonnull__(1)));
# 209 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strchr(const char * , int ) __attribute__((__nonnull__(1)));
# 218 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) size_t strcspn(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 232 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strpbrk(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 247 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strrchr(const char * , int ) __attribute__((__nonnull__(1)));
# 257 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) size_t strspn(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 270 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strstr(const char * , const char * ) __attribute__((__nonnull__(1,2)));
# 280 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) char *strtok(char * __restrict , const char * __restrict ) __attribute__((__nonnull__(2)));
extern __attribute__((__nothrow__)) char *_strtok_r(char * , const char * , char ** ) __attribute__((__nonnull__(2,3)));
# 321 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) void *memset(void * , int , size_t ) __attribute__((__nonnull__(1)));





extern __attribute__((__nothrow__)) char *strerror(int );







extern __attribute__((__nothrow__)) size_t strlen(const char * ) __attribute__((__nonnull__(1)));





extern __attribute__((__nothrow__)) size_t strnlen(const char * , size_t ) __attribute__((__nonnull__(1)));







extern __attribute__((__nothrow__)) size_t strlcpy(char * , const char * , size_t ) __attribute__((__nonnull__(1,2)));
# 369 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) size_t strlcat(char * , const char * , size_t ) __attribute__((__nonnull__(1,2)));
# 395 "C:\\Users\\marwa\\AppData\\Local\\Keil_v5\\ARM\\ARMCLANG\\bin\\..\\include\\string.h" 3
extern __attribute__((__nothrow__)) void _membitcpybl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitcpybb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitcpyhl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitcpyhb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitcpywl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitcpywb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovebl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovebb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovehl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovehb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovewl(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
extern __attribute__((__nothrow__)) void _membitmovewb(void * , const void * , int , int , size_t ) __attribute__((__nonnull__(1,2)));
# 4 "Source/platform/exam_board.c" 2








extern uint32_t SystemFrequency;

typedef struct {
  volatile uint8_t pending;
  volatile uint8_t confirmed;
  volatile uint16_t ticks;
} button_state_t;

static button_state_t button_state[3u];
static button_callback_t button_callback;
static joystick_callback_t joystick_callback;
static volatile uint32_t button_confirm_ticks = 50u / 10u;
static volatile uint32_t scheduler_tick_count;
static volatile uint32_t joystick_last;
static volatile uint32_t joystick_first;
static volatile uint32_t event_flags;
static timer_callback_t timer_callbacks[4u];
static uint8_t timer_claimed[4u];
static uint8_t systick_periodic;
static volatile uint32_t systick_tick_count;
static adc_sample_t adc_cache[8u];
static volatile uint32_t adc_cache_generation[8u];
static uint32_t adc_actual_clock;
static adc_trigger_t adc_trigger = ADC_TRIGGER_SOFTWARE;
static uint32_t potentiometer_seen_generation;

typedef struct {
  const uint16_t *samples;
  uint32_t count;
  uint32_t index;
  uint8_t timer;
  uint8_t active;
} dac_player_t;
static dac_player_t dac_player;

unsigned char led_value;
unsigned short AD_current;

static LPC_TIM_TypeDef *timer_regs(uint8_t timer)
{
  switch (timer) {
    case 0: return ((LPC_TIM_TypeDef *) ((0x40000000UL) + 0x04000) );
    case 1: return ((LPC_TIM_TypeDef *) ((0x40000000UL) + 0x08000) );
    case 2: return ((LPC_TIM_TypeDef *) ((0x40080000UL) + 0x10000) );
    case 3: return ((LPC_TIM_TypeDef *) ((0x40080000UL) + 0x14000) );
    default: return 0;
  }
}

static IRQn_Type timer_irqn(uint8_t timer)
{
  switch (timer) {
    case 0: return TIMER0_IRQn;
    case 1: return TIMER1_IRQn;
    case 2: return TIMER2_IRQn;
    default: return TIMER3_IRQn;
  }
}

static void timer_power_on(uint8_t timer)
{
  static const uint8_t bits[4u] = { 1u, 2u, 22u, 23u };
  ((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->PCONP |= 1u << bits[timer];
}



static volatile uint32_t *timer_pclk_select(uint8_t timer, uint8_t *shift)
{
  if (!shift) return 0;
  switch (timer) {
    case 0u: *shift = 2u; return &((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->PCLKSEL0;
    case 1u: *shift = 4u; return &((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->PCLKSEL0;
    case 2u: *shift = 12u; return &((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->PCLKSEL1;
    case 3u: *shift = 14u; return &((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->PCLKSEL1;
    default: return 0;
  }
}


static uint32_t button_gpio_bit(board_button_t button)
{
  return 1u << (10u + (uint32_t)button);
}


static void button_pin_as_eint(board_button_t button)
{
  uint32_t shift = 20u + 2u * (uint32_t)button;
  ((LPC_PINCON_TypeDef *) ((0x40000000UL) + 0x2C000) )->PINSEL4 = (((LPC_PINCON_TypeDef *) ((0x40000000UL) + 0x2C000) )->PINSEL4 & ~(3u << shift)) | (1u << shift);
}


static void button_pin_as_gpio(board_button_t button)
{
  uint32_t shift = 20u + 2u * (uint32_t)button;
  ((LPC_PINCON_TypeDef *) ((0x40000000UL) + 0x2C000) )->PINSEL4 &= ~(3u << shift);
  ((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIODIR &= ~button_gpio_bit(button);
}


static IRQn_Type button_irqn(board_button_t button)
{
  return (button == BOARD_BUTTON_INT0) ? EINT0_IRQn :
         (button == BOARD_BUTTON_KEY1) ? EINT1_IRQn : EINT2_IRQn;
}


static void button_candidate(board_button_t button)
{
  uint32_t bit = 1u << (uint32_t)button;
  __NVIC_DisableIRQ(button_irqn(button));
  ((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->EXTINT = bit;
  button_pin_as_gpio(button);
  button_state[button].pending = 1u;
  button_state[button].confirmed = 0u;
  button_state[button].ticks = 0u;
}



static void button_service_10ms(void)
{
  uint32_t i;
  for (i = 0; i < 3u; ++i) {
    button_state_t *state = &button_state[i];
    uint8_t low;
    if (!state->pending) continue;
    low = (((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIOPIN & button_gpio_bit((board_button_t)i)) == 0u;
    if (!state->confirmed) {
      if (++state->ticks < button_confirm_ticks) continue;
      if (low) {
        state->confirmed = 1u;
        if (button_callback) button_callback((board_button_t)i, BUTTON_EVENT_PRESS);
      } else {
        state->pending = 0u;
        button_pin_as_eint((board_button_t)i);
        __NVIC_EnableIRQ(button_irqn((board_button_t)i));
      }
    } else if (!low) {
      state->pending = 0u;
      state->confirmed = 0u;
      if (button_callback) button_callback((board_button_t)i, BUTTON_EVENT_RELEASE);
      button_pin_as_eint((board_button_t)i);
      ((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->EXTINT = 1u << i;
      __NVIC_EnableIRQ(button_irqn((board_button_t)i));
    }
  }
}

static void joystick_service_10ms(void)
{
  static uint32_t divider;
  uint32_t current, changed;
  if (++divider < (50u / 10u)) return;
  divider = 0u;
  current = joystick_read();
  changed = current ^ joystick_last;
  if (joystick_first == 0u && current != 0u) joystick_first = current;
  joystick_last = current;
  if (changed && joystick_callback) joystick_callback(current, changed);
}


void __attribute__((weak)) exam_user_10ms_hook(void) { }

void board_init(void)
{
  SystemInit();

  ((LPC_PINCON_TypeDef *) ((0x40000000UL) + 0x2C000) )->PINSEL4 &= ~0xFFFFu;
  ((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIODIR |= 0xFFu;
  ((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIOCLR = 0xFFu;
  led_value = 0u;


  buttons_init(0);


  joystick_init(0);


  (void)rit_scheduler_start();


  (void)adc_init(5u, SystemFrequency / 4u);


  (void)dac_init();

  fault_traps_configure();
}

void board_idle(void)
{
  ((SCB_Type *) ((0xE000E000UL) + 0x0D00UL) )->SCR &= ~((1UL << 2U) | (1UL << 1U));
  __builtin_arm_wfi();
}




board_status_t timer_every_ms(int timer, int milliseconds, timer_callback_t callback)
{
  if (timer < 0 || timer >= (int)4u || milliseconds <= 0)
    return BOARD_RANGE;
  return timer_start_periodic_interrupt_ms((uint8_t)timer,
                                           (uint32_t)milliseconds, callback);
}

board_status_t timer_every_hz(int timer, int hertz, timer_callback_t callback)
{
  if (timer < 0 || timer >= (int)4u || hertz <= 0)
    return BOARD_RANGE;
  return timer_start_periodic_interrupt_hz((uint8_t)timer, (uint32_t)hertz,
                                           1u, callback);
}

board_status_t systick_every_ms(int milliseconds)
{
  if (milliseconds <= 0) return BOARD_RANGE;
  return systick_start_periodic_ms((uint32_t)milliseconds);
}

board_status_t potentiometer_start(void)
{
  board_status_t status = adc_configure_trigger(ADC_TRIGGER_SOFTWARE, 0u);
  if (status != BOARD_OK) return status;
  potentiometer_seen_generation = adc_cache_generation[5];
  return adc_start_conversion();
}

board_status_t potentiometer_read(int *value)
{
  if (!value) return BOARD_INVALID;
  if (adc_cache_generation[5] == potentiometer_seen_generation)
    return BOARD_NOT_READY;
  *value = (int)adc_cache[5].value;
  potentiometer_seen_generation = adc_cache_generation[5];
  (void)adc_start_conversion();
  return BOARD_OK;
}

board_status_t speaker_write(int value)
{
  if (value < 0 || value > 1023) return BOARD_RANGE;
  return dac_write((uint16_t)value);
}

board_status_t speaker_write_percent(int percent)
{
  if (percent < 0 || percent > 100) return BOARD_RANGE;
  return dac_write((uint16_t)((percent * 1023 + 50) / 100));
}

int int0_pressed(void) { return (int)button_is_pressed(BOARD_BUTTON_INT0); }
int key1_pressed(void) { return (int)button_is_pressed(BOARD_BUTTON_KEY1); }
int key2_pressed(void) { return (int)button_is_pressed(BOARD_BUTTON_KEY2); }
int joystick_up_pressed(void) { return (int)joystick_is_pressed(JOYSTICK_UP); }
int joystick_down_pressed(void) { return (int)joystick_is_pressed(JOYSTICK_DOWN); }
int joystick_left_pressed(void) { return (int)joystick_is_pressed(JOYSTICK_LEFT); }
int joystick_right_pressed(void) { return (int)joystick_is_pressed(JOYSTICK_RIGHT); }
int joystick_button_pressed(void) { return (int)joystick_is_pressed(JOYSTICK_SELECT); }

board_status_t led_write_number(uint8_t led_number, uint8_t on)
{

  uint8_t port_bit;
  if (led_number >= 4u && led_number <= 11u) port_bit = (uint8_t)(11u - led_number);
  else return BOARD_RANGE;
  if (on) ((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIOSET = 1u << port_bit;
  else ((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIOCLR = 1u << port_bit;
  led_value = (unsigned char)(((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIOPIN & 0xFFu);
  return BOARD_OK;



}



board_status_t led_on(uint8_t led_number) { return led_write_number(led_number, 1u); }
board_status_t led_off(uint8_t led_number) { return led_write_number(led_number, 0u); }
void led_all_off(void) { (void)led_write_mask(0u); }

board_status_t led_write_mask(uint8_t mask)
{

  ((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIOCLR = 0xFFu;
  ((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIOSET = mask;
  led_value = mask;
  return BOARD_OK;



}

board_status_t led_toggle(uint8_t led_number)
{
  uint8_t bit;
  if (led_number >= 4u && led_number <= 11u) bit = (uint8_t)(11u - led_number);
  else return BOARD_RANGE;
  return led_write_number(led_number, (uint8_t)((((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIOPIN & (1u << bit)) == 0u));
}

uint8_t led_read_mask(void) { return (uint8_t)(((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIOPIN & 0xFFu); }
void led_write8(uint8_t value) { (void)led_write_mask(value); }

void buttons_init(button_callback_t callback)
{
  uint32_t i;
  button_callback = callback;
  for (i = 0; i < 3u; ++i) {
    button_state[i].pending = button_state[i].confirmed = 0u;
    button_state[i].ticks = 0u;
    button_pin_as_eint((board_button_t)i);
    __NVIC_ClearPendingIRQ(button_irqn((board_button_t)i));
    __NVIC_EnableIRQ(button_irqn((board_button_t)i));
  }
  ((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->EXTMODE |= 0x7u;
  ((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->EXTPOLAR &= ~0x7u;
  ((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->EXTINT = 0x7u;
}

void buttons_set_confirmation_ms(uint32_t milliseconds)
{
  if (milliseconds >= 10u && milliseconds % 10u == 0u)
    button_confirm_ticks = milliseconds / 10u;
}

uint32_t buttons_pressed_mask(void)
{
  return (~((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) )->FIOPIN >> 10) & 0x7u;
}

uint8_t button_is_pressed(board_button_t button)
{
  if ((uint32_t)button >= 3u) return 0u;
  return (uint8_t)((buttons_pressed_mask() & (1u << (uint32_t)button)) != 0u);
}

void joystick_init(joystick_callback_t callback)
{
  const uint32_t mask = 0x1Fu << 25;
  ((LPC_PINCON_TypeDef *) ((0x40000000UL) + 0x2C000) )->PINSEL3 &= ~((3u << 18) | (3u << 20) | (3u << 22) | (3u << 24) | (3u << 26));
  ((LPC_PINCON_TypeDef *) ((0x40000000UL) + 0x2C000) )->PINMODE3 &= ~((3u << 18) | (3u << 20) | (3u << 22) | (3u << 24) | (3u << 26));
  ((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00020) )->FIODIR &= ~mask;
  joystick_callback = callback;
  joystick_last = joystick_read();
  joystick_first = 0u;
}

uint32_t joystick_read(void)
{
  uint32_t pins = (~((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00020) )->FIOPIN >> 25) & 0x1Fu;
  uint32_t result = 0u;
  if (pins & (1u << 0)) result |= JOYSTICK_SELECT;
  if (pins & (1u << 1)) result |= JOYSTICK_DOWN;
  if (pins & (1u << 2)) result |= JOYSTICK_LEFT;
  if (pins & (1u << 3)) result |= JOYSTICK_RIGHT;
  if (pins & (1u << 4)) result |= JOYSTICK_UP;
  return result;
}

uint8_t joystick_is_pressed(uint32_t direction)
{
  if (direction == 0u || (direction & ~0x1Fu) != 0u) return 0u;
  return (uint8_t)((joystick_read() & direction) == direction);
}

uint32_t joystick_first_movement(void) { return joystick_first; }
void joystick_reset_first_movement(void) { joystick_first = 0u; }

board_status_t timer_set_clock_divider(uint8_t timer, uint8_t divider)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  volatile uint32_t *selection;
  uint32_t encoding;
  uint8_t shift;


  switch (divider) {
    case 1u: encoding = 1u; break;
    case 2u: encoding = 2u; break;
    case 4u: encoding = 0u; break;
    case 8u: encoding = 3u; break;
    default: return BOARD_RANGE;
  }

  selection = timer_pclk_select(timer, &shift);
  if (!t || !selection) return BOARD_RANGE;
  timer_power_on(timer);
  if (t->TCR & 1u) return BOARD_BUSY;
  *selection = (*selection & ~(3u << shift)) | (encoding << shift);
  return BOARD_OK;
}

uint32_t timer_peripheral_clock_hz(uint8_t timer)
{
  volatile uint32_t *selection;
  uint32_t encoding;
  uint32_t divider;
  uint8_t shift;

  selection = timer_pclk_select(timer, &shift);
  if (!selection) return 0u;
  encoding = (*selection >> shift) & 3u;

  divider = (encoding == 0u) ? 4u :
            (encoding == 1u) ? 1u :
            (encoding == 2u) ? 2u : 8u;
  return SystemFrequency / divider;
}

board_status_t timer_set_prescaler(uint8_t timer, uint32_t prescaler)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  if (!t) return BOARD_RANGE;
  timer_power_on(timer);
  t->PR = prescaler;
  return BOARD_OK;
}

uint32_t timer_counter_clock_hz(uint8_t timer)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  uint32_t peripheral_clock;
  uint64_t divisor;

  if (!t || (t->CTCR & 3u) != TIMER_MODE_TIMER) return 0u;
  peripheral_clock = timer_peripheral_clock_hz(timer);
  divisor = (uint64_t)t->PR + 1u;
  return (uint32_t)((uint64_t)peripheral_clock / divisor);
}

board_status_t timer_calculate_match_for_frequency(uint8_t timer, uint32_t frequency_hz,
                                                   uint32_t events_per_cycle, uint32_t *match_value)
{
  uint32_t counter_clock;
  uint64_t events_per_second;
  uint64_t ticks;

  if (!match_value || frequency_hz == 0u || events_per_cycle == 0u) return BOARD_INVALID;
  counter_clock = timer_counter_clock_hz(timer);
  if (counter_clock == 0u) return BOARD_RANGE;

  events_per_second = (uint64_t)frequency_hz * events_per_cycle;
  if (events_per_second > counter_clock) return BOARD_RANGE;


  ticks = ((uint64_t)counter_clock + events_per_second / 2u) / events_per_second;
  if (ticks == 0u || ticks > 0xFFFFFFFFu) return BOARD_RANGE;
  *match_value = (uint32_t)ticks;
  return BOARD_OK;
}

board_status_t timer_configure_frequency(uint8_t timer, uint8_t match, uint32_t frequency_hz,
                                         uint32_t events_per_cycle, uint32_t actions)
{
  uint32_t match_value;
  board_status_t status = timer_calculate_match_for_frequency(
      timer, frequency_hz, events_per_cycle, &match_value);
  if (status != BOARD_OK) return status;
  return timer_configure_match(timer, match, match_value, actions);
}

uint8_t timer_match_occurred(uint32_t pending_flags, uint8_t match)
{
  if (match > 3u) return 0u;
  return (uint8_t)((pending_flags & (1u << match)) != 0u);
}

uint8_t timer_capture_occurred(uint32_t pending_flags, uint8_t capture)
{
  if (capture > 1u) return 0u;
  return (uint8_t)((pending_flags & (1u << (4u + capture))) != 0u);
}

board_status_t timer_start_periodic_interrupt_hz(uint8_t timer, uint32_t frequency_hz,
                                                 uint32_t events_per_cycle,
                                                 timer_callback_t callback)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  board_status_t status;

  if (!t) return BOARD_RANGE;
  if (!callback) return BOARD_INVALID;
  if (t->TCR & 1u) return BOARD_BUSY;



  status = timer_configure_frequency(timer, 0u, frequency_hz, events_per_cycle,
                                     TIMER_ACTION_INTERRUPT | TIMER_ACTION_RESET);
  if (status != BOARD_OK) return status;
  status = timer_set_callback(timer, callback);
  if (status != BOARD_OK) return status;

  (void)timer_reset(timer);
  t->IR = 0x3Fu;
  return timer_start(timer);
}

board_status_t timer_start_periodic_interrupt_ms(uint8_t timer, uint32_t period_ms,
                                                 timer_callback_t callback)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  uint32_t counter_clock;
  uint64_t ticks;
  board_status_t status;

  if (!t) return BOARD_RANGE;
  if (!callback || period_ms == 0u) return BOARD_INVALID;
  if (t->TCR & 1u) return BOARD_BUSY;
  counter_clock = timer_counter_clock_hz(timer);
  if (counter_clock == 0u) return BOARD_RANGE;



  ticks = ((uint64_t)counter_clock * period_ms + 500u) / 1000u;
  if (ticks == 0u || ticks > 0xFFFFFFFFu) return BOARD_RANGE;
  status = timer_configure_match(timer, 0u, (uint32_t)ticks,
                                 TIMER_ACTION_INTERRUPT | TIMER_ACTION_RESET);
  if (status != BOARD_OK) return status;
  status = timer_set_callback(timer, callback);
  if (status != BOARD_OK) return status;
  (void)timer_reset(timer);
  t->IR = 0x3Fu;
  return timer_start(timer);
}

board_status_t timer_configure_match(uint8_t timer, uint8_t match, uint32_t value, uint32_t actions)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  uint32_t shift;
  volatile uint32_t *mr;
  if (!t || match > 3u || (actions & ~7u)) return BOARD_RANGE;
  timer_power_on(timer);
  mr = &t->MR0;
  mr[match] = value;
  shift = 3u * match;
  t->MCR = (t->MCR & ~(7u << shift)) | ((actions & 7u) << shift);
  if (actions & TIMER_ACTION_INTERRUPT) {
    __NVIC_ClearPendingIRQ(timer_irqn(timer));
    __NVIC_EnableIRQ(timer_irqn(timer));
  }
  return BOARD_OK;
}

board_status_t timer_configure_capture(uint8_t timer, uint8_t capture, timer_capture_edge_t edge, uint8_t interrupt_enable)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  uint32_t shift;
  if (!t || capture > 1u || edge < CAPTURE_RISING || edge > CAPTURE_BOTH) return BOARD_RANGE;
  timer_power_on(timer);
  shift = capture * 3u;
  t->CCR = (t->CCR & ~(7u << shift)) | (((uint32_t)edge | (interrupt_enable ? 4u : 0u)) << shift);
  if (interrupt_enable) __NVIC_EnableIRQ(timer_irqn(timer));
  return BOARD_OK;
}

board_status_t timer_read_capture(uint8_t timer, uint8_t capture, uint32_t *value)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  if (!t || capture > 1u || !value) return BOARD_INVALID;
  *value = capture ? t->CR1 : t->CR0;
  return BOARD_OK;
}

board_status_t timer_set_counter_mode(uint8_t timer, timer_counter_mode_t mode, uint8_t capture_input)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  if (!t || mode > TIMER_MODE_COUNTER_BOTH || capture_input > 1u) return BOARD_RANGE;
  timer_power_on(timer);
  t->CTCR = (uint32_t)mode | ((uint32_t)capture_input << 2);
  return BOARD_OK;
}

board_status_t timer_configure_external_match(uint8_t timer, uint8_t match, timer_external_match_t action, uint8_t initial_state)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  uint32_t shift;
  if (!t || match > 3u || action > EXT_MATCH_TOGGLE) return BOARD_RANGE;
  timer_power_on(timer);
  shift = 4u + match * 2u;
  t->EMR = (t->EMR & ~((3u << shift) | (1u << match))) |
           ((uint32_t)action << shift) | (initial_state ? (1u << match) : 0u);
  return BOARD_OK;
}

board_status_t timer_start(uint8_t timer) { LPC_TIM_TypeDef *t = timer_regs(timer); if (!t) return BOARD_RANGE; t->TCR = 1u; return BOARD_OK; }
board_status_t timer_stop(uint8_t timer) { LPC_TIM_TypeDef *t = timer_regs(timer); if (!t) return BOARD_RANGE; t->TCR = 0u; return BOARD_OK; }
board_status_t timer_reset(uint8_t timer) { LPC_TIM_TypeDef *t = timer_regs(timer); if (!t) return BOARD_RANGE; t->TCR = 2u; t->TCR = 0u; return BOARD_OK; }
board_status_t timer_set_callback(uint8_t timer, timer_callback_t callback) { if (timer >= 4u) return BOARD_RANGE; if (timer_claimed[timer]) return BOARD_BUSY; timer_callbacks[timer] = callback; return BOARD_OK; }
uint32_t timer_read_counter(uint8_t timer) { LPC_TIM_TypeDef *t = timer_regs(timer); return t ? t->TC : 0u; }


static void timer_irq(uint8_t timer)
{
  LPC_TIM_TypeDef *t = timer_regs(timer);
  uint32_t pending = t->IR & 0x3Fu;
  t->IR = pending;
  if (dac_player.active && dac_player.timer == timer && (pending & 1u)) {
    (void)dac_write(dac_player.samples[dac_player.index++]);
    if (dac_player.index >= dac_player.count) { dac_player.active = 0u; timer_claimed[timer] = 0u; (void)timer_stop(timer); dac_silence(); }
  }
  if (timer_callbacks[timer]) timer_callbacks[timer](timer, pending);
}





void TIMER1_IRQHandler(void) { timer_irq(1u); }


void TIMER2_IRQHandler(void) { timer_irq(2u); }


void TIMER3_IRQHandler(void) { timer_irq(3u); }



board_status_t rit_scheduler_start(void)
{

  ((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->PCONP |= 1u << 16;
  ((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->PCLKSEL1 = (((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->PCLKSEL1 & ~(3u << 26)) | (1u << 26);
  ((LPC_RIT_TypeDef *) ((0x40080000UL) + 0x30000) )->RICOMPVAL = SystemFrequency / (1000u / 10u);
  ((LPC_RIT_TypeDef *) ((0x40080000UL) + 0x30000) )->RIMASK = 0u;
  ((LPC_RIT_TypeDef *) ((0x40080000UL) + 0x30000) )->RICOUNTER = 0u;
  ((LPC_RIT_TypeDef *) ((0x40080000UL) + 0x30000) )->RICTRL = (1u << 1) | (1u << 2) | (1u << 3);
  __NVIC_ClearPendingIRQ(RIT_IRQn);
  __NVIC_EnableIRQ(RIT_IRQn);
  return BOARD_OK;



}
void rit_scheduler_stop(void) { ((LPC_RIT_TypeDef *) ((0x40080000UL) + 0x30000) )->RICTRL &= ~(1u << 3); }
uint32_t rit_scheduler_ticks(void) { return scheduler_tick_count; }

board_status_t rit_raw_configure(uint32_t compare, uint32_t mask, uint8_t clear_on_match)
{







  (void)compare; (void)mask; (void)clear_on_match; return BOARD_BUSY;

}
board_status_t rit_raw_start(void) { if (1 != 2) return BOARD_BUSY; ((LPC_RIT_TypeDef *) ((0x40080000UL) + 0x30000) )->RICTRL |= 1u << 3; return BOARD_OK; }
void rit_raw_stop(void) { ((LPC_RIT_TypeDef *) ((0x40080000UL) + 0x30000) )->RICTRL &= ~(1u << 3); }
uint32_t rit_raw_read(void) { return ((LPC_RIT_TypeDef *) ((0x40080000UL) + 0x30000) )->RICOUNTER; }


void RIT_IRQHandler(void)
{
  ((LPC_RIT_TypeDef *) ((0x40080000UL) + 0x30000) )->RICTRL |= 1u;

  ++scheduler_tick_count;
  button_service_10ms();
  joystick_service_10ms();
  exam_user_10ms_hook();

}


board_status_t systick_configure(uint32_t reload, uint8_t periodic, uint8_t interrupt_enable)
{
  uint32_t source = ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL & (1UL << 2U);
  if (reload == 0u || reload > 0x00FFFFFFu) return BOARD_RANGE;
  ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL = 0u;
  ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->LOAD = reload - 1u;
  ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->VAL = 0u;
  systick_periodic = periodic ? 1u : 0u;
  ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL = source | (interrupt_enable ? (1UL << 1U) : 0u) | (1UL );
  return BOARD_OK;
}
board_status_t systick_start_periodic_ms(uint32_t period_ms)
{
  uint64_t reload;
  if (period_ms == 0u) return BOARD_INVALID;
  reload = ((uint64_t)SystemFrequency * period_ms + 500u) / 1000u;
  if (reload == 0u || reload > 0x00FFFFFFu) return BOARD_RANGE;
  (void)systick_set_clock_source(1u);
  return systick_configure((uint32_t)reload, 1u, 1u);
}
board_status_t systick_set_clock_source(uint8_t processor_clock) { uint32_t enabled = ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL & (1UL ); ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL &= ~(1UL ); if (processor_clock) ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL |= (1UL << 2U); else ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL &= ~(1UL << 2U); ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL |= enabled; return BOARD_OK; }
uint32_t systick_calibration_value(void) { return ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CALIB & (0xFFFFFFUL ); }
uint8_t systick_has_precise_calibration(void) { return (uint8_t)((((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CALIB & (1UL << 31U)) == 0u && (((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CALIB & (1UL << 30U)) == 0u); }
uint32_t systick_ticks(void) { return systick_tick_count; }

void SysTick_Handler(void) { ++systick_tick_count; if (!systick_periodic) ((SysTick_Type *) ((0xE000E000UL) + 0x0010UL) )->CTRL &= ~(1UL ); }


board_status_t adc_init(uint8_t channel, uint32_t peripheral_clock_hz)
{
  uint32_t divider;
  if (channel >= 8u || peripheral_clock_hz == 0u) return BOARD_RANGE;
  ((LPC_SC_TypeDef *) ((0x40080000UL) + 0x7C000) )->PCONP |= 1u << 12;
  divider = (peripheral_clock_hz + 13000000u - 1u) / 13000000u;
  if (divider == 0u) divider = 1u;
  if (divider > 256u) return BOARD_RANGE;
  adc_actual_clock = peripheral_clock_hz / divider;
  if (channel == 5u) ((LPC_PINCON_TypeDef *) ((0x40000000UL) + 0x2C000) )->PINSEL3 = (((LPC_PINCON_TypeDef *) ((0x40000000UL) + 0x2C000) )->PINSEL3 & ~(3u << 30)) | (3u << 30);
  ((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) )->ADCR = (1u << channel) | ((divider - 1u) << 8) | (1u << 21);
  ((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) )->ADINTEN = 1u << 8;
  __NVIC_ClearPendingIRQ(ADC_IRQn);
  __NVIC_EnableIRQ(ADC_IRQn);
  return BOARD_OK;
}

board_status_t adc_configure_trigger(adc_trigger_t trigger, uint8_t falling_edge)
{
  if (trigger != ADC_TRIGGER_SOFTWARE && (trigger < ADC_TRIGGER_P2_10 || trigger > ADC_TRIGGER_MAT1_1)) return BOARD_RANGE;
  adc_trigger = trigger;
  ((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) )->ADCR = (((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) )->ADCR & ~((7u << 24) | (1u << 27))) |
                  ((uint32_t)trigger << 24) | (falling_edge ? (1u << 27) : 0u);
  return BOARD_OK;
}

board_status_t adc_start_conversion(void)
{
  if (adc_trigger != ADC_TRIGGER_SOFTWARE) return BOARD_BUSY;
  ((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) )->ADCR = (((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) )->ADCR & ~(7u << 24)) | (1u << 24);
  return BOARD_OK;
}

board_status_t adc_start_burst(uint32_t channel_mask)
{
  if ((channel_mask & 0xFFu) == 0u || (channel_mask & ~0xFFu)) return BOARD_RANGE;
  ((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) )->ADCR = (((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) )->ADCR & ~((0xFFu) | (7u << 24))) | channel_mask | (1u << 16);
  return BOARD_OK;
}
void adc_stop_burst(void) { ((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) )->ADCR &= ~(1u << 16); }


static void adc_cache_raw(uint32_t raw)
{
  uint8_t channel = (uint8_t)((raw >> 24) & 7u);
  adc_cache[channel].raw = raw;
  adc_cache[channel].value = (uint16_t)((raw >> 4) & 0x0FFFu);
  adc_cache[channel].channel = channel;
  adc_cache[channel].done = (uint8_t)((raw >> 31) & 1u);
  adc_cache[channel].overrun = (uint8_t)((raw >> 30) & 1u);
  ++adc_cache_generation[channel];
  if (channel == 5u) AD_current = adc_cache[channel].value;
}


void ADC_IRQHandler(void)
{
  uint32_t raw = ((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) )->ADGDR;
  adc_cache_raw(raw);
}



board_status_t adc_read_channel(uint8_t channel, adc_sample_t *sample)
{
  if (channel >= 8u || !sample) return BOARD_INVALID;
  if (!adc_cache_generation[channel]) return BOARD_NOT_READY;
  *sample = adc_cache[channel];
  return BOARD_OK;
}
board_status_t adc_read_value(uint8_t channel, uint16_t *value)
{
  adc_sample_t sample;
  board_status_t status;
  if (!value) return BOARD_INVALID;
  status = adc_read_channel(channel, &sample);
  if (status != BOARD_OK) return status;
  *value = sample.value;
  return BOARD_OK;
}
uint32_t adc_clock_hz(void) { return adc_actual_clock; }

board_status_t dac_init(void)
{

  ((LPC_PINCON_TypeDef *) ((0x40000000UL) + 0x2C000) )->PINSEL1 = (((LPC_PINCON_TypeDef *) ((0x40000000UL) + 0x2C000) )->PINSEL1 & ~(3u << 20)) | (2u << 20);



  dac_silence(); return BOARD_OK;



}
board_status_t dac_write(uint16_t value) { if (value > 1023u) return BOARD_RANGE; ((LPC_DAC_TypeDef *) ((0x40080000UL) + 0x0C000) )->DACR = (uint32_t)value << 6; return BOARD_OK; }
void dac_silence(void) { ((LPC_DAC_TypeDef *) ((0x40080000UL) + 0x0C000) )->DACR = 0u; }
board_status_t dac_validate_update_rate(uint32_t update_hz) { return (update_hz && update_hz <= 1000000u) ? BOARD_OK : BOARD_RANGE; }

board_status_t dac_play_samples(const uint16_t *samples, uint32_t count, uint32_t update_hz, uint8_t timer)
{
  uint32_t ticks;
  if (!samples || !count || timer >= 4u) return BOARD_INVALID;
  if (dac_validate_update_rate(update_hz) != BOARD_OK) return BOARD_RANGE;
  if (timer_claimed[timer]) return BOARD_BUSY;
  timer_claimed[timer] = 1u;
  dac_player.samples = samples; dac_player.count = count; dac_player.index = 0u; dac_player.timer = timer; dac_player.active = 1u;
  ticks = (SystemFrequency / 4u) / update_hz;
  (void)timer_set_prescaler(timer, 0u);
  (void)timer_configure_match(timer, 0u, ticks, TIMER_ACTION_INTERRUPT | TIMER_ACTION_RESET);
  return timer_start(timer);
}

uint32_t critical_enter(void) { uint32_t previous = __get_PRIMASK(); __disable_irq(); __builtin_arm_dmb(0xF); return previous; }
void critical_exit(uint32_t previous_primask) { __builtin_arm_dmb(0xF); __set_PRIMASK(previous_primask); }
void event_flags_set(uint32_t flags) { uint32_t key = critical_enter(); event_flags |= flags; critical_exit(key); }
uint32_t event_flags_take(uint32_t mask) { uint32_t key = critical_enter(); uint32_t result = event_flags & mask; event_flags &= ~mask; critical_exit(key); return result; }

void *board_direct_register(const char *name)
{
  if (!name) return 0;
  if (!strcmp(name, "GPIO1")) return ((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00020) );
  if (!strcmp(name, "GPIO2")) return ((LPC_GPIO_TypeDef *) ((0x2009C000UL) + 0x00040) );
  if (!strcmp(name, "TIMER0")) return ((LPC_TIM_TypeDef *) ((0x40000000UL) + 0x04000) );
  if (!strcmp(name, "TIMER1")) return ((LPC_TIM_TypeDef *) ((0x40000000UL) + 0x08000) );
  if (!strcmp(name, "TIMER2")) return ((LPC_TIM_TypeDef *) ((0x40080000UL) + 0x10000) );
  if (!strcmp(name, "TIMER3")) return ((LPC_TIM_TypeDef *) ((0x40080000UL) + 0x14000) );
  if (!strcmp(name, "RIT")) return ((LPC_RIT_TypeDef *) ((0x40080000UL) + 0x30000) );
  if (!strcmp(name, "ADC")) return ((LPC_ADC_TypeDef *) ((0x40000000UL) + 0x34000) );
  if (!strcmp(name, "DAC")) return ((LPC_DAC_TypeDef *) ((0x40080000UL) + 0x0C000) );
  return 0;
}


void EINT0_IRQHandler(void) { button_candidate(BOARD_BUTTON_INT0); }


void EINT1_IRQHandler(void) { button_candidate(BOARD_BUTTON_KEY1); }


void EINT2_IRQHandler(void) { button_candidate(BOARD_BUTTON_KEY2); }


uint32_t board_self_test_run(void)
{
  uint32_t failed = 0u;

  uint8_t saved = led_read_mask();
  if (led_write_mask(0xA5u) != BOARD_OK || led_read_mask() != 0xA5u) failed |= SELF_TEST_LED_API;
  (void)led_write_mask(saved);

  if (joystick_read() & ~0x1Fu) failed |= SELF_TEST_JOYSTICK_IDLE;
  if (adc_clock_hz() > 13000000u) failed |= SELF_TEST_ADC_CLOCK;
  if (systick_configure(0x01000001u, 1u, 1u) != BOARD_RANGE) failed |= SELF_TEST_SYSTICK_RANGE;
  if (dac_validate_update_rate(1000000u + 1u) != BOARD_RANGE) failed |= SELF_TEST_DAC_RANGE;
  return failed;
}
