# 3 February 2026 ARM3 solution map

- The foreground displays the ADC's upper eight bits.
- KEY2 uses the confirmed-button system, calls `Recaman`, and displays `a0`.
- Timer0 displays each following term every two seconds.
- Fit JP12 when testing the potentiometer on the physical board.
